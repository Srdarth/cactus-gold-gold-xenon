Curso Python Papo Reto (pacote offline)
- Pasta apostilas/: PDFs por aula
- Pasta arquivos_de_treino/: dados para exercícios e mini-projetos
Dica: crie uma pasta 'meus_testes_python' e copie os arquivos de treino para lá antes de rodar scripts.
