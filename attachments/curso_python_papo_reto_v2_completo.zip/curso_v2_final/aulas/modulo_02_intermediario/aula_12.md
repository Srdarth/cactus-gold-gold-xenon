# Aula 12 — pip e ambientes: requirements.txt, venv e dependências sem bagunça

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
### Dependência é “coisa que seu código precisa”
Ex.: `requests`, `fastapi`, `pydantic`.

O objetivo do `requirements.txt` é simples:
- Qualquer pessoa roda: `pip install -r requirements.txt`
- E tem exatamente o mesmo “kit” que você


### Checklist de projeto limpo
- `venv/` (não versionar)
- `requirements.txt`
- `src/` ou pasta do projeto
- `README.md` com como rodar




## Exemplo guiado
Arquivo desta aula: **`codigo/aula_12_pip_e_ambientes_requirementstxt_venv_e_d.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_12_pip_e_ambientes_requirementstxt_ven.py`
   - Linux/Mac: `python3 codigo/aula_12_pip_e_ambientes_requirementstxt_ven.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
Use o exemplo desta aula como peça de lego: você monta coisas maiores juntando essas peças.

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
