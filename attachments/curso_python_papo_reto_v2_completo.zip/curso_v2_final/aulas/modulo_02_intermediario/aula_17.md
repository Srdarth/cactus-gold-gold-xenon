# Aula 17 — HTTP e APIs: requests, status codes, headers e JSON

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
### Como Python “conecta” com a internet
A internet é basicamente:
- você faz uma **requisição** (pedido)
- o servidor responde com um **status** e um **conteúdo** (muitas vezes JSON)

Python entra como “cola” usando bibliotecas como `requests`.


### Status code que você PRECISA decorar
- `200` OK
- `201` Created
- `400` Bad Request (você pediu errado)
- `401/403` sem permissão
- `404` não existe
- `500` erro no servidor




## Exemplo guiado
Arquivo desta aula: **`codigo/aula_17_http_e_apis_requests_status_codes_header.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_17_http_e_apis_requests_status_codes_h.py`
   - Linux/Mac: `python3 codigo/aula_17_http_e_apis_requests_status_codes_h.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
APIs são como apps conversam (Pix, delivery, redes sociais, tudo).

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.
- Adicione tratamento de erro e mensagens amigáveis (papo reto).

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
