# Aula 11 — Organizando o código: módulos, pacotes e import do jeito certo

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
### Por que módulos e pacotes existem?
Quando seu código cresce, um arquivo único vira um monstro.  
Módulos/pacotes existem para você separar:
- **Regras do negócio**
- **Entrada/saída** (terminal, arquivo, API)
- **Dados** (banco, JSON)

Isso deixa o projeto:
- mais fácil de manter
- mais fácil de testar
- mais fácil de evoluir


### Regras de import que evitam dor
- Evite `from x import *`
- Prefira imports explícitos
- Use `if __name__ == "__main__":` para definir “ponto de entrada” do programa




## Exemplo guiado
Arquivo desta aula: **`codigo/aula_11_organizando_o_codigo_modulos_pacotes_e_i.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_11_organizando_o_código_módulos_pacote.py`
   - Linux/Mac: `python3 codigo/aula_11_organizando_o_código_módulos_pacote.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
Use o exemplo desta aula como peça de lego: você monta coisas maiores juntando essas peças.

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
