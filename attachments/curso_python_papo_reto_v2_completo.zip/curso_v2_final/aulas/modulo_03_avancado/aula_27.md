# Aula 27 — Backend com FastAPI: rotas, validação (Pydantic) e estrutura

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
### Backend é: “um programa que fica esperando pedidos”
Uma API é um conjunto de rotas, ex:
- `GET /` → “tá vivo?”
- `GET /clientes` → lista
- `POST /clientes` → cria

FastAPI deixa isso simples e com validação automática.


### Estrutura mínima que funciona (papo reto)
- `app = FastAPI()`
- `@app.get(...)` / `@app.post(...)`
- modelos `BaseModel` para validar entrada/saída
- rodar com `uvicorn`




## Exemplo guiado
Arquivo desta aula: **`codigo/aula_27_backend_com_fastapi_rotas_validacao_pyda.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_27_backend_com_fastapi_rotas_validação.py`
   - Linux/Mac: `python3 codigo/aula_27_backend_com_fastapi_rotas_validação.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
FastAPI vira “servidor” local: você cria um backend de verdade.

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.
- Adicione tratamento de erro e mensagens amigáveis (papo reto).
- Teste a API via /docs e anote o que muda quando você envia dados inválidos.

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
