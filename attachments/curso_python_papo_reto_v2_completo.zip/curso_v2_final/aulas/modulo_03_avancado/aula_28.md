# Aula 28 — Conectando com JavaScript: fetch(), CORS e consumo de API

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
### A ponte Python ↔ JavaScript
- Python (FastAPI) entrega JSON
- JavaScript faz `fetch()` e consome esse JSON

É literalmente “troca de mensagens” via HTTP.


### CORS em 1 frase
CORS é uma trava do navegador.  
Se seu frontend (site) está em um domínio/porta e sua API em outro, o browser bloqueia por segurança — e você precisa liberar.




## Exemplo guiado
Arquivo desta aula: **`codigo/aula_28_conectando_com_javascript_fetch_cors_e_c.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_28_conectando_com_javascript_fetch_cor.py`
   - Linux/Mac: `python3 codigo/aula_28_conectando_com_javascript_fetch_cor.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
Aqui você conecta o que a Júlia curte (JS) com Python backend.

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
