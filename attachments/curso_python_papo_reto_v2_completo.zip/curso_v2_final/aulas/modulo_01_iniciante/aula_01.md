# Aula 01 — Como o Python funciona (interprete, script, REPL)

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
### Mentalidade: Python é um **motor** (interprete) + **peças** (módulos) + **combustível** (dados)

Quando você “roda Python”, você não está “compilando um programa” do jeito clássico.  
Você está pedindo para um **programa chamado interpretador** ler seu arquivo de cima pra baixo e executar as instruções.

- **Arquivo `.py`**: receita (texto)
- **Interpretador**: cozinheiro (executa)
- **Bibliotecas**: ingredientes e utensílios prontos
- **Ambiente (venv)**: sua cozinha separada (não mistura ingredientes com outras receitas)

Isso responde a pergunta da Júlia: *“como o Python conecta as coisas?”*  
Ele conecta porque consegue **ler arquivos**, **falar com a internet**, **acessar banco**, **rodar bibliotecas**, e você “cola” tudo com código.


### Por trás dos panos (bem direto)
- `python arquivo.py` → o interpretador lê o arquivo, cria objetos em memória e executa.
- O Python mantém um **namespace** (uma “tabela” de nomes → valores).
- Cada vez que você `import x`, o Python procura esse módulo em uma lista de caminhos (`sys.path`), carrega e guarda em cache (`sys.modules`).


### Comparação rápida com JavaScript
- JS no browser tem o “ambiente” do navegador (DOM, fetch, etc.).
- JS no Node.js tem o ambiente do Node (fs, http, etc.).
- Python também tem um “ambiente”: o interpretador + bibliotecas + seu sistema operacional.
**Conclusão:** Python é backend porque roda “do lado do servidor” (ou do seu PC) e conversa com o mundo via bibliotecas.


## Exemplo guiado
Arquivo desta aula: **`codigo/aula_01_como_o_python_funciona_interprete_script.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_01_como_o_python_funciona_interprete_s.py`
   - Linux/Mac: `python3 codigo/aula_01_como_o_python_funciona_interprete_s.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
Você usa esse modelo mental para entender por que às vezes “funciona no meu PC” e no outro não (spoiler: venv e dependências).

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
