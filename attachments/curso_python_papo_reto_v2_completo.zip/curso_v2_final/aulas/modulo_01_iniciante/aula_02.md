# Aula 02 — Setup sem dor: Python, VS Code, terminal, venv (o mínimo)

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
### Setup sem drama (o mínimo que funciona)
Você só precisa de 3 coisas:
1. **Python instalado**
2. **Editor** (VS Code recomendado)
3. **Terminal** (onde você roda comandos)

E a quarta coisa que salva sua vida:
4. **Ambiente virtual (venv)** — evita bagunça de bibliotecas.


### O que é `venv` na prática?
Quando você instala uma biblioteca com `pip`, ela vai para algum lugar no disco.

Sem `venv`:
- Bibliotecas de projetos diferentes se misturam
- Um update quebra o outro

Com `venv`:
- Cada projeto tem sua “pasta de bibliotecas”
- Você sabe exatamente o que instalou

Pensa assim: **cada projeto tem sua própria mochila** de ferramentas.


### Comparando com JavaScript (npm)
- `npm install` cria `node_modules` por projeto (isola dependências).
- Em Python, a isolação é feita pelo `venv` + `pip`.


## Exemplo guiado
Arquivo desta aula: **`codigo/aula_02_setup_sem_dor_python_vs_code_terminal_ve.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_02_setup_sem_dor_python_vs_code_termin.py`
   - Linux/Mac: `python3 codigo/aula_02_setup_sem_dor_python_vs_code_termin.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
Projeto com venv é projeto que você consegue retomar depois de meses sem sofrer.

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
