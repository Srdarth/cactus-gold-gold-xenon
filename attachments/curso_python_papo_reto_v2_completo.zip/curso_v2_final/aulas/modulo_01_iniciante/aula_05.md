# Aula 05 — Strings na vida real: f-strings, slicing, métodos e validação

## Objetivo
Ao final desta aula, você consegue explicar **com suas palavras**:
- o que este conceito faz
- por que ele existe
- como usar em um exemplo real

## Explicação (Papo Reto)
Nesta aula você vai aprender o conceito e aplicar em exemplos pequenos. Depois, a gente conecta isso em um projeto real.





## Exemplo guiado
Arquivo desta aula: **`codigo/aula_05_strings_na_vida_real_f-strings_slicing_m.py`**

1. Abra o arquivo.
2. Rode no terminal:
   - Windows: `py codigo/aula_05_strings_na_vida_real_f-strings_slic.py`
   - Linux/Mac: `python3 codigo/aula_05_strings_na_vida_real_f-strings_slic.py`
3. Leia o código e responda:
   - “O que entra?”
   - “O que sai?”
   - “O que muda na memória?”

## Mundo real
Use o exemplo desta aula como peça de lego: você monta coisas maiores juntando essas peças.

## Erros comuns
- Rodar fora da pasta do projeto e “não achar arquivo”.
- Copiar/colar sem entender (aqui a regra é: rode → quebre → conserte).

## Exercícios
- Reescreva o exemplo com seus próprios nomes/valores.
- Quebre o código de propósito (erro de tipo, variável não definida, etc.) e explique o erro.
- Crie uma variação do exemplo para um caso real seu.
- Adicione tratamento de erro e mensagens amigáveis (papo reto).

## Checklist de domínio
- [ ] Consigo explicar o conceito sem olhar a aula
- [ ] Consigo reproduzir o exemplo do zero
- [ ] Consigo criar uma variação minha
- [ ] Sei qual erro comum eu cometi e como evitar
