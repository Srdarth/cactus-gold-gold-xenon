"""Soluções (resumo) — Módulo 2"""

from pathlib import Path
import csv, json

def contar_txt(path: Path):
    texto = path.read_text(encoding="utf-8", errors="ignore")
    linhas = texto.splitlines()
    palavras = [p for linha in linhas for p in linha.split()]
    return len(linhas), len(palavras)

def relatorio_pasta(pasta: Path, saida_csv: Path):
    rows=[]
    for p in pasta.rglob("*"):
        if p.is_file():
            rows.append({
                "arquivo": p.name,
                "ext": p.suffix.lower(),
                "tamanho_bytes": p.stat().st_size
            })
    with saida_csv.open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=["arquivo","ext","tamanho_bytes"])
        w.writeheader()
        w.writerows(rows)

if __name__ == "__main__":
    pasta = Path(".")
    out = Path("relatorio.csv")
    relatorio_pasta(pasta, out)
    print("Gerado:", out.resolve())
