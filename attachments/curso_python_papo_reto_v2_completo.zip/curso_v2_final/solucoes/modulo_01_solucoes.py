"""Soluções (resumo) — Módulo 1

Atenção: existem várias soluções possíveis. Aqui vai uma versão simples e comentada.
"""

def dias_vividos():
    nome = input("Nome: ").strip()
    idade = int(input("Idade (anos): ").strip())
    print(f"{nome}, você viveu ~{idade*365} dias (aprox.).")

def senha_valida(senha: str) -> bool:
    if len(senha) < 8:
        return False
    tem_numero = any(ch.isdigit() for ch in senha)
    return tem_numero

def demo_senha():
    s = input("Senha: ")
    print("OK" if senha_valida(s) else "Senha fraca")

if __name__ == "__main__":
    # Descomente para testar:
    # dias_vividos()
    demo_senha()
