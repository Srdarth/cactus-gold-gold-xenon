"""Soluções (resumo) — Módulo 3"""

from dataclasses import dataclass

@dataclass
class Produto:
    nome: str
    preco: float

    def aplicar_desconto(self, pct: float) -> None:
        if not (0 <= pct <= 100):
            raise ValueError("pct deve estar entre 0 e 100")
        self.preco *= (1 - pct/100)

class Timer:
    def __enter__(self):
        import time
        self._t0 = time.time()
        return self
    def __exit__(self, exc_type, exc, tb):
        import time
        dt = time.time() - self._t0
        print(f"Tempo: {dt:.4f}s")

if __name__ == "__main__":
    p=Produto("Café", 12.50)
    p.aplicar_desconto(10)
    print(p)

    with Timer():
        s=sum(range(1_000_00))
        print(s)
