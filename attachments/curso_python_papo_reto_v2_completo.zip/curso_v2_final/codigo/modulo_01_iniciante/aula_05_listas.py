#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 05 — Listas
================
Como guardar vários valores em uma única variável ordenada.
"""

print("=" * 60)
print("EXEMPLO DA AULA 05: Listas")
print("=" * 60)

# Criando listas
frutas = ["maçã", "banana", "laranja", "uva", "manga"]
numeros = [10, 20, 30, 40, 50]
misturado = ["texto", 42, 3.14, True, None]

print(f"\nLista de frutas: {frutas}")
print(f"Quantidade: {len(frutas)} itens")

# Acessando por índice (começa em 0!)
print(f"\nPrimeira fruta: {frutas[0]}")
print(f"Última fruta: {frutas[-1]}")
print(f"Fatiamento [1:4]: {frutas[1:4]}")

# Modificando
frutas[1] = "banana nanica"
print(f"\nDepois de alterar: {frutas}")

# Adicionando e removendo
frutas.append("abacaxi")       # adiciona no final
frutas.insert(0, "morango")    # insere na posição
frutas.remove("laranja")       # remove por valor
removida = frutas.pop()        # remove e retorna o último

print(f"Depois de adicionar/remover: {frutas}")
print(f"Item removido com pop(): {removida}")

# Úteis
print(f"\nLista ordenada: {sorted(frutas)}")
print(f"'uva' está na lista? {'uva' in frutas}")
print(f"Posição de 'uva': {frutas.index('uva')}")

# Percorrendo
print("\n--- Percorrendo com for ---")
for fruta in frutas:
    print(f"  - {fruta.upper()}")

# --- DESAFIO ---
# Crie uma lista de 5 notas, calcule a média e diga se o aluno foi aprovado.
# Inverta a ordem de uma lista sem usar reverse().

print("\n💡 Dica: listas são MUTÁVEIS — podem mudar depois de criadas!")
