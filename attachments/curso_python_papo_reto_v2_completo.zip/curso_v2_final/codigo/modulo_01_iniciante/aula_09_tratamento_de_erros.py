#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 09 — Tratamento de erros (try/except)
============================================
Como fazer o programa não "quebrar" quando algo dá errado.
"""

print("=" * 60)
print("EXEMPLO DA AULA 09: try / except / else / finally")
print("=" * 60)

# --- Problema: divisão por zero ---
print("\n--- 1. Divisão segura ---")
try:
    numerador = float(input("Digite o numerador: "))
    denominador = float(input("Digite o denominador: "))
    resultado = numerador / denominador
except ZeroDivisionError:
    print("❌ ERRO: Não pode dividir por zero!")
except ValueError:
    print("❌ ERRO: Digite um número válido!")
else:
    print(f"✅ Resultado: {resultado}")
finally:
    print("📌 Isso sempre executa, com erro ou não.")

# --- Problema: arquivo não existe ---
print("\n--- 2. Abrindo arquivo com segurança ---")
try:
    with open("arquivo_que_nao_existe.txt", "r") as f:
        print(f.read())
except FileNotFoundError:
    print("❌ Arquivo não encontrado. Vou criar um exemplo...")
    with open("arquivo_que_nao_existe.txt", "w") as f:
        f.write("Agora eu existo!\n")
    print("✅ Arquivo criado com sucesso.")

# --- Capturando múltiplos erros e detalhes ---
print("\n--- 3. Detalhes do erro ---")
try:
    lista = [1, 2, 3]
    print(lista[10])  # índice fora do range
except (IndexError, KeyError) as e:
    print(f"❌ Erro de acesso: {type(e).__name__} — {e}")

# --- raise: lançando seu próprio erro ---
print("\n--- 4. Lançando erro personalizado ---")
def sacar(saldo, valor):
    if valor > saldo:
        raise ValueError(f"Saldo insuficiente! Tem R${saldo}, tentou sacar R${valor}")
    return saldo - valor

try:
    novo_saldo = sacar(100, 150)
    print(f"Novo saldo: R${novo_saldo}")
except ValueError as e:
    print(f"❌ {e}")

# --- DESAFIO ---
# Crie um programa que pede um número ao usuário e mostra a raiz quadrada.
# Trate: número negativo (ValueError), texto inválido (ValueError).

print("\n💡 Dica: Não use except 'nu' (vazio). Capture erros ESPECÍFICOS!")
