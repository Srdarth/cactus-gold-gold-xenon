#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 07 — Arquivos e pastas
============================
Como ler e escrever arquivos no disco com Python.
"""

import os
from pathlib import Path

print("=" * 60)
print("EXEMPLO DA AULA 07: Arquivos e pastas")
print("=" * 60)

# 1. ESCREVER um arquivo
print("\n--- 1. Escrevendo arquivo ---")
with open("exemplo_aula07.txt", "w", encoding="utf-8") as arquivo:
    arquivo.write("Primeira linha do meu arquivo\n")
    arquivo.write("Segunda linha com Python\n")
    arquivo.write("Terceira linha: 12345\n")
print("✅ Arquivo 'exemplo_aula07.txt' criado!")

# 2. LER um arquivo inteiro
print("\n--- 2. Lendo arquivo inteiro ---")
with open("exemplo_aula07.txt", "r", encoding="utf-8") as arquivo:
    conteudo = arquivo.read()
print(conteudo)

# 3. LER linha por linha
print("--- 3. Lendo linha por linha ---")
with open("exemplo_aula07.txt", "r", encoding="utf-8") as arquivo:
    for i, linha in enumerate(arquivo, 1):
        print(f"  Linha {i}: {linha.strip()}")

# 4. Trabalhando com pastas (Pathlib - moderno)
print("\n--- 4. Explorando pastas ---")
pasta_atual = Path(".")
print(f"Pasta atual: {pasta_atual.absolute()}")

print("\nArquivos .py na pasta:")
for arq in sorted(pasta_atual.glob("*.py")):
    tamanho = arq.stat().st_size
    print(f"  📄 {arq.name} ({tamanho} bytes)")

# 5. Criar pasta se não existir
pasta_nova = Path("minha_pasta_teste")
pasta_nova.mkdir(exist_ok=True)
print(f"\n✅ Pasta '{pasta_nova}' garantida!")

# 6. Verificar existência
arquivo_teste = Path("exemplo_aula07.txt")
print(f"\nArquivo existe? {arquivo_teste.exists()}")
print(f"É arquivo? {arquivo_teste.is_file()}")
print(f"É pasta? {arquivo_teste.is_dir()}")

# Limpeza (opcional)
# arquivo_teste.unlink(missing_ok=True)
# pasta_nova.rmdir()

# --- DESAFIO ---
# Crie um programa que pede um texto ao usuário e salva em um arquivo.
# Depois leia o arquivo e mostre quantas linhas e quantas palavras tem.

print("\n💡 Dica: SEMPRE use 'with open()' — fecha o arquivo automaticamente!")
