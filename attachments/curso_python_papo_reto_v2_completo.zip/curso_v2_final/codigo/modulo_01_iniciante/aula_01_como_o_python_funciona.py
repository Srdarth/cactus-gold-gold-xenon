#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 01 — Como o Python funciona (interprete, script, REPL)
===========================================================
Exemplo prático: mostra como o interpretador executa linha a linha
e como as variáveis vivem na memória.
"""

print("=" * 60)
print("EXEMPLO DA AULA 01: Python como motor + receita + dados")
print("=" * 60)

# Estas linhas são executadas DE CIMA PARA BAIXO
nome = "Júlia"               # variável guardada na memória
idade = 25                    # outra variável
ano_nascimento = 2026 - idade # cálculo feito na hora

print(f"\nOlá, {nome}!")
print(f"Você tem {idade} anos.")
print(f"Você provavelmente nasceu em {ano_nascimento}.")

# --- EXERCÍCIO: quebre este código de propósito ---
# Tente:
# 1. Apagar o "f" do f-string e veja o que acontece
# 2. Trocar "idade" por uma palavra que não existe
# 3. Mudar os valores e explicar o que mudou na memória

print("\n✅ Fim do exemplo. Agora tente quebrá-lo e entender o erro!")
