#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 08 — Dicionários
======================
Como guardar pares de chave → valor (estrutura de dados mais útil do Python).
"""

print("=" * 60)
print("EXEMPLO DA AULA 08: Dicionários")
print("=" * 60)

# Criando um dicionário
pessoa = {
    "nome": "Isabella",
    "idade": 22,
    "cidade": "Rio de Janeiro",
    "profissao": "Criadora Virtual",
    "hobbies": ["fotografia", "viagem", "música"],
    "ativa": True
}

print(f"\nDicionário completo: {pessoa}")

# Acessando valores
print(f"\nNome: {pessoa['nome']}")
print(f"Idade: {pessoa['idade']}")
print(f"Primeiro hobby: {pessoa['hobbies'][0]}")

# Acesso seguro com get()
print(f"Altura (não existe): {pessoa.get('altura', 'não informado')}")

# Modificando e adicionando
pessoa["idade"] = 23                    # altera existente
pessoa["altura"] = 1.68                 # adiciona nova chave
pessoa["hobbies"].append("tecnologia")  # adiciona na lista

# Removendo
del pessoa["ativa"]
profissao = pessoa.pop("profissao")

print(f"\nDepois das alterações:")
for chave, valor in pessoa.items():
    print(f"  {chave}: {valor}")

# Verificando existência
print(f"\n'nome' está nas chaves? {'nome' in pessoa}")
print(f"Chaves: {list(pessoa.keys())}")
print(f"Valores: {list(pessoa.values())}")

# Lista de dicionários = banco de dados simples
print("\n--- Lista de pessoas (mini banco) ---")
pessoas = [
    {"nome": "Ana", "idade": 25, "cidade": "SP"},
    {"nome": "Bruno", "idade": 30, "cidade": "RJ"},
    {"nome": "Carla", "idade": 28, "cidade": "BH"}
]

for p in pessoas:
    print(f"  {p['nome']} tem {p['idade']} anos e mora em {p['cidade']}")

# --- DESAFIO ---
# Crie um dicionário que funciona como agenda telefônica.
# Permita ao usuário: adicionar contato, buscar, listar todos, remover.

print("\n💡 Dica: dicionário = {'chave': 'valor'}. Acesso O(1) — muito rápido!")
