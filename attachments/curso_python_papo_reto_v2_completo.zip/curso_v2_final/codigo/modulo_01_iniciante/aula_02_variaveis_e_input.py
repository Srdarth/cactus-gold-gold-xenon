#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 02 — Variáveis e input
============================
Como guardar dados na memória e pedir informação ao usuário.
"""

print("=" * 60)
print("EXEMPLO DA AULA 02: Variáveis + input()")
print("=" * 60)

# Variáveis são como "caixas" com nome na memória
nome = input("\nQual é o seu nome? ")
idade_str = input("Quantos anos você tem? ")

# input() SEMPRE retorna texto — precisamos converter para número
idade = int(idade_str)
meses = idade * 12
dias = idade * 365

print(f"\n--- Resultado ---")
print(f"Nome: {nome}")
print(f"Idade: {idade} anos")
print(f"Isso dá aproximadamente {meses} meses de vida")
print(f"Ou aproximadamente {dias} dias de vida")

# --- DESAFIO ---
# Peça também a cidade onde a pessoa mora e mostre uma frase personalizada.
# Tente converter para float e veja o que acontece se digitar texto.

print("\n💡 Dica: input() sempre retorna string. Use int() ou float() para números!")
