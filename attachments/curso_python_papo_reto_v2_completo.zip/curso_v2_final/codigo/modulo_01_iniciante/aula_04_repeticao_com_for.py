#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 04 — Repetição com for
============================
Como repetir ações sem copiar e colar código.
"""

print("=" * 60)
print("EXEMPLO DA AULA 04: Laço for")
print("=" * 60)

# 1. Repetir um número fixo de vezes com range()
print("\n--- Contagem de 1 a 10 ---")
for numero in range(1, 11):
    print(f"  {numero}")

# 2. Percorrer uma lista de nomes
print("\n--- Lista de convidados ---")
convidados = ["Ana", "Bruno", "Carla", "Daniel", "Elisa"]
for posicao, nome in enumerate(convidados, start=1):
    print(f"  {posicao}. {nome}")

# 3. Tabuada
print("\n--- Tabuada do 7 ---")
for i in range(1, 11):
    resultado = 7 * i
    print(f"  7 × {i:2d} = {resultado:2d}")

# 4. Soma acumulada
print("\n--- Soma dos números de 1 a 100 ---")
soma = 0
for n in range(1, 101):
    soma += n
print(f"  Total = {soma}")

# --- DESAFIO ---
# Mostre a tabuada completa de 1 a 10 (use um for DENTRO de outro for).
# Conte quantos números pares existem entre 1 e 1000.

print("\n💡 Dica: for = 'para cada'. range(inicio, fim, passo). fim NÃO é incluído!")
