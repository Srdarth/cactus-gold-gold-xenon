#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 06 — Funções (seus atalhos)
=================================
Como criar blocos de código reutilizáveis.
"""

print("=" * 60)
print("EXEMPLO DA AULA 06: Funções")
print("=" * 60)

# Função SIMPLES sem parâmetros
def saudacao():
    print("\n👋 Olá! Bem-vindo ao curso de Python!")
    print("Funções evitam repetição de código.")

# Função COM parâmetros
def calcular_imc(peso, altura):
    """Calcula o Índice de Massa Corporal."""
    imc = peso / (altura ** 2)
    return imc

# Função com parâmetro PADRÃO
def apresentar(nome, profissao="estudante"):
    print(f"\nPrazer, eu sou {nome} e trabalho como {profissao}.")

# --- USANDO AS FUNÇÕES ---
saudacao()

apresentar("Maria", "engenheira")
apresentar("João")  # usa o padrão "estudante"

meu_imc = calcular_imc(70, 1.75)
print(f"\nSeu IMC é: {meu_imc:.2f}")

if meu_imc < 18.5:
    print("Classificação: Abaixo do peso")
elif meu_imc < 25:
    print("Classificação: Peso normal")
elif meu_imc < 30:
    print("Classificação: Sobrepeso")
else:
    print("Classificação: Obesidade")

# Função com múltiplos retornos
def analisar_lista(numeros):
    return min(numeros), max(numeros), sum(numeros) / len(numeros)

menor, maior, media = analisar_lista([10, 20, 30, 40, 50])
print(f"\n--- Análise de lista ---")
print(f"Menor: {menor} | Maior: {maior} | Média: {media}")

# --- DESAFIO ---
# Crie uma função que recebe um número e retorna True se for par, False se for ímpar.
# Crie uma função que conta quantas vogais existem em uma frase.

print("\n💡 Dica: def = 'definir função'. return devolve o resultado para quem chamou.")
