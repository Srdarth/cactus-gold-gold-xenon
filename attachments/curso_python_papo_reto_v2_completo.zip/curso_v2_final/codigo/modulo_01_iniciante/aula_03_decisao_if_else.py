#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 03 — Decisões com if/else
===============================
Como fazer o programa tomar decisões baseadas em condições.
"""

print("=" * 60)
print("EXEMPLO DA AULA 03: if / elif / else")
print("=" * 60)

idade = int(input("\nDigite sua idade: "))

print("\n--- Análise ---")
if idade < 0:
    print("❌ Idade inválida (não pode ser negativa)")
elif idade < 12:
    print("👶 Criança")
elif idade < 18:
    print("🧑 Adolescente — menor de idade")
elif idade < 30:
    print("🧑 Jovem adulto")
elif idade < 60:
    print("👨 Adulto")
else:
    print("👴 Idoso")

# Exemplo com AND e OR
tem_carteira = input("\nTem carteira de motorista? (s/n): ").lower().startswith('s')
idade_maior = idade >= 18

if idade_maior and tem_carteira:
    print("✅ Você PODE dirigir legalmente")
elif idade_maior and not tem_carteira:
    print("⚠️ Você tem idade mas NÃO tem carteira — não pode dirigir")
else:
    print("❌ Você ainda NÃO tem idade para dirigir")

# --- DESAFIO ---
# Crie um programa que pede uma nota (0-10) e diz se foi aprovado (>=7),
# recuperação (5-6.9) ou reprovado (<5).

print("\n💡 Dica: if = 'se', elif = 'senão se', else = 'senão'. Ordem importa!")
