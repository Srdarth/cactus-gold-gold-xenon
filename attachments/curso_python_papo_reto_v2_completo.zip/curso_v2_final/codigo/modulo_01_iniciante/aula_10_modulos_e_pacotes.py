#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 10 — Módulos e pacotes
=============================
Como usar código que já existe (padrão ou de terceiros).
"""

import math
import random
import datetime
from collections import Counter
from pathlib import Path as Caminho  # pode dar apelido!

print("=" * 60)
print("EXEMPLO DA AULA 10: Módulos e importações")
print("=" * 60)

# 1. Módulo math — funções matemáticas
print("\n--- 1. Módulo math ---")
print(f"π = {math.pi:.6f}")
print(f"√25 = {math.sqrt(25)}")
print(f"sen(90°) = {math.sin(math.radians(90)):.4f}")
print(f"5! = {math.factorial(5)}")
print(f"log₂(1024) = {math.log2(1024)}")

# 2. Módulo random — aleatoriedade
print("\n--- 2. Módulo random ---")
random.seed(42)  # para reprodutibilidade
print(f"Número aleatório 0-1: {random.random():.4f}")
print(f"Inteiro entre 1 e 10: {random.randint(1, 10)}")
frutas = ["maçã", "banana", "laranja", "uva"]
print(f"Escolha aleatória: {random.choice(frutas)}")
random.shuffle(frutas)
print(f"Lista embaralhada: {frutas}")

# 3. Módulo datetime — data e hora
print("\n--- 3. Módulo datetime ---")
agora = datetime.datetime.now()
print(f"Agora: {agora}")
print(f"Data: {agora.strftime('%d/%m/%Y')}")
print(f"Hora: {agora.strftime('%H:%M:%S')}")
natal = datetime.date(2026, 12, 25)
hoje = datetime.date.today()
dias_para_natal = (natal - hoje).days
print(f"Dias para o Natal: {dias_para_natal}")

# 4. collections.Counter — contagem fácil
print("\n--- 4. collections.Counter ---")
texto = "banana"
contagem = Counter(texto)
print(f"Contagem em 'banana': {dict(contagem)}")
print(f"Mais comum: {contagem.most_common(2)}")

# 5. Criando seu próprio módulo
print("\n--- 5. Seu próprio módulo ---")
print("💡 Crie um arquivo 'meu_modulo.py' com funções.")
print("💡 Depois use: 'import meu_modulo' ou 'from meu_modulo import minha_funcao'")

# 6. Instalando pacotes de terceiros
print("\n--- 6. Pacotes de terceiros ---")
print("💡 No terminal: pip install requests pandas numpy")
print("💡 Depois: import requests")

# --- DESAFIO ---
# Use o módulo random para criar um jogo de "pedra, papel, tesoura" contra o computador.
# Use datetime para calcular quantos dias você já viveu.

print("\n💡 Dica: Python vem com +200 módulos padrão! A biblioteca padrão é sua amiga.")
