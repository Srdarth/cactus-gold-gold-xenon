#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 25 — FastAPI: crie APIs modernas em minutos
=================================================
O framework web mais rápido e moderno do ecossistema Python.
"""

print("=" * 60)
print("EXEMPLO DA AULA 25: FastAPI")
print("=" * 60)

print("📌 Instale: pip install fastapi uvicorn")
print("📌 Rode:    uvicorn arquivo:app --reload")
print("📌 Docs:    http://localhost:8000/docs (Swagger UI automático!)\n")

codigo_api = '''
# ===== Salve isto como: main.py =====
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(
    title="EDS Produtos API",
    description="API de exemplo do Curso Python Papo Reto",
    version="1.0.0"
)

# ===== Modelo de dados (validação automática) =====
class Produto(BaseModel):
    id: Optional[int] = None
    nome: str
    preco: float
    estoque: int = 0
    categoria: str = "geral"

class ProdutoAtualizacao(BaseModel):
    nome: Optional[str] = None
    preco: Optional[float] = None
    estoque: Optional[int] = None
    categoria: Optional[str] = None

# ===== Banco em memória (para exemplo) =====
banco: dict[int, Produto] = {}
proximo_id = 1

# ===== ROTAS =====

@app.get("/", tags=["Raiz"])
def raiz():
    """Endpoint inicial — verifica se API está no ar."""
    return {"mensagem": "API EDS funcionando!", "docs": "/docs"}

@app.get("/produtos", response_model=List[Produto], tags=["Produtos"])
def listar_produtos(categoria: Optional[str] = None, preco_max: Optional[float] = None):
    """Lista todos os produtos, com filtros opcionais."""
    resultado = list(banco.values())
    if categoria:
        resultado = [p for p in resultado if p.categoria.lower() == categoria.lower()]
    if preco_max is not None:
        resultado = [p for p in resultado if p.preco <= preco_max]
    return resultado

@app.get("/produtos/{produto_id}", response_model=Produto, tags=["Produtos"])
def buscar_produto(produto_id: int):
    """Busca um produto pelo ID. Retorna 404 se não existir."""
    produto = banco.get(produto_id)
    if not produto:
        raise HTTPException(status_code=404, detail=f"Produto {produto_id} não encontrado")
    return produto

@app.post("/produtos", response_model=Produto, status_code=201, tags=["Produtos"])
def criar_produto(produto: Produto):
    """Cria um novo produto. Validação automática pelo Pydantic!"""
    global proximo_id
    produto.id = proximo_id
    banco[proximo_id] = produto
    proximo_id += 1
    return produto

@app.put("/produtos/{produto_id}", response_model=Produto, tags=["Produtos"])
def atualizar_produto(produto_id: int, dados: ProdutoAtualizacao):
    """Atualiza apenas os campos enviados (PATCH-like)."""
    produto = banco.get(produto_id)
    if not produto:
        raise HTTPException(status_code=404, detail=f"Produto {produto_id} não encontrado")
    
    dados_dict = dados.model_dump(exclude_unset=True)
    for chave, valor in dados_dict.items():
        setattr(produto, chave, valor)
    
    return produto

@app.delete("/produtos/{produto_id}", status_code=204, tags=["Produtos"])
def deletar_produto(produto_id: int):
    """Remove um produto."""
    if produto_id not in banco:
        raise HTTPException(status_code=404, detail=f"Produto {produto_id} não encontrado")
    del banco[produto_id]

# ===== Para rodar diretamente =====
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
'''

print(codigo_api)

print("\n--- 🚀 COMO TESTAR ---")
print("""
1. Salve o código acima como 'main.py'
2. Terminal: uvicorn main:app --reload
3. Abra no navegador: http://localhost:8000/docs
4. Clique em 'Try it out' → 'Execute' em qualquer rota!

Ou use curl/requests:
   POST http://localhost:8000/produtos
   body: {"nome": "Isabella OS", "preco": 27, "estoque": 999, "categoria": "Software"}
""")

# --- Por que FastAPI? ---
print("\n--- 💡 POR QUE FASTAPI? ---")
print("""
✅ Rápido como Node/Go (baseado em Starlette + Pydantic)
✅ Documentação Swagger/OpenAPI AUTOMÁTICA em /docs
✅ Validação de dados AUTOMÁTICA com Pydantic
✅ Tipos Python = documentação e validação
✅ Suporte nativo a async/await
✅ Perfeito para APIs REST, microsserviços, backend web
""")

# --- DESAFIO ---
# Estenda esta API:
# 1. Adicione um endpoint GET /produtos/estatisticas que retorna total, preço médio, estoque total
# 2. Adicione autenticação simples com uma chave de API no header
# 3. Troque o banco em memória por SQLite real

print("\n💡 Dica: FastAPI transforma tipos Python em contrato de API. /docs é seu melhor amigo!")
