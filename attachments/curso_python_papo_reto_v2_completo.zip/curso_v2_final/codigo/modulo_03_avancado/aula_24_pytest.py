#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 24 — Testes automatizados com pytest
==========================================
Tenha certeza que seu código funciona — sem testar manualmente.
"""

print("=" * 60)
print("EXEMPLO DA AULA 24: pytest")
print("=" * 60)

print("📌 Instale: pip install pytest")
print("📌 Rode:    pytest arquivo.py -v\n")

# --- CÓDIGO PARA TESTAR ---
def calcular_imposto(valor, aliquota=0.18):
    """Calcula imposto sobre um valor."""
    if valor < 0:
        raise ValueError("Valor não pode ser negativo")
    return valor * aliquota

def classificar_produto(preco):
    """Classifica produto por faixa de preço."""
    if preco <= 0:
        raise ValueError("Preço inválido")
    elif preco < 50:
        return "econômico"
    elif preco < 200:
        return "padrão"
    else:
        return "premium"

def aplicar_desconto(valor, desconto_percentual):
    """Aplica desconto percentual."""
    if not (0 <= desconto_percentual <= 100):
        raise ValueError("Desconto deve ser entre 0 e 100")
    return valor * (1 - desconto_percentual / 100)

# --- TESTES (salve em arquivo separado: test_*.py) ---
print("--- EXEMPLO DE TESTES (arquivo test_calculos.py) ---")
testes_exemplo = '''
import pytest
from calculos import calcular_imposto, classificar_produto, aplicar_desconto

# ===== Testes simples com assert =====
def test_calcular_imposto_basico():
    assert calcular_imposto(100) == 18.0

def test_calcular_imposto_aliquota_custom():
    assert calcular_imposto(200, aliquota=0.10) == 20.0

def test_calcular_imposto_zero():
    assert calcular_imposto(0) == 0.0

# ===== Testando que ERRO acontece =====
def test_calcular_imposto_negativo():
    with pytest.raises(ValueError, match="não pode ser negativo"):
        calcular_imposto(-50)

# ===== Testes parametrizados (vários casos de uma vez) =====
@pytest.mark.parametrize("preco, esperado", [
    (10, "econômico"),
    (49.99, "econômico"),
    (50, "padrão"),
    (199.99, "padrão"),
    (200, "premium"),
    (1000, "premium"),
])
def test_classificar_produto_varios_casos(preco, esperado):
    assert classificar_produto(preco) == esperado

# ===== Fixtures: dados reutilizáveis =====
@pytest.fixture
def carrinho_exemplo():
    """Dados para usar em múltiplos testes."""
    return {"itens": [100, 50, 75], "total": 225}

def test_desconto_no_carrinho(carrinho_exemplo):
    total = carrinho_exemplo["total"]
    com_desconto = aplicar_desconto(total, 10)
    assert com_desconto == pytest.approx(202.5)  # aproximação para floats

# ===== Tipos de teste =====
# smoke test: funciona sem explodir?
# unit test:  testa uma função isolada
# integration test: testa várias partes juntas
# end-to-end: testa o fluxo completo
'''

print(testes_exemplo)

# --- Rodando os testes "na mão" com assert ---
print("\n--- RODANDO TESTES MANUALMENTE ---")
testes_passaram = 0
testes_totais = 0

def teste(nome, condicao):
    global testes_passaram, testes_totais
    testes_totais += 1
    status = "✅ PASSOU" if condicao else "❌ FALHOU"
    print(f"  {status} | {nome}")
    if condicao:
        testes_passaram += 1

teste("imposto 100 → 18", calcular_imposto(100) == 18.0)
teste("imposto 200 @10% → 20", calcular_imposto(200, 0.10) == 20.0)
teste("classificar 10 → econômico", classificar_produto(10) == "econômico")
teste("classificar 100 → padrão", classificar_produto(100) == "padrão")
teste("classificar 500 → premium", classificar_produto(500) == "premium")
teste("desconto 10% em 100 → 90", aplicar_desconto(100, 10) == 90.0)

try:
    calcular_imposto(-10)
    teste("valor negativo deve dar erro", False)
except ValueError:
    teste("valor negativo deve dar erro", True)

print(f"\n📊 Resultado: {testes_passaram}/{testes_totais} testes passaram")

# --- Boas práticas ---
print("\n--- ✅ BOAS PRÁTICAS DE TESTE ---")
print("""
• Nomeie testes como: test_o_que_testa_o_que_espera
• Um teste = UMA afirmação principal
• Teste casos NORMAIS, de BORDA e de ERRO
• Use pytest.mark.parametrize para múltiplos casos
• Fixtures para dados repetitivos
• Rode testes ANTES de commitar/deployar
• Cobertura de código: pip install pytest-cov → pytest --cov=meu_modulo
""")

# --- DESAFIO ---
# Escreva testes completos para uma função de validação de senha:
# - Mínimo 8 caracteres
# - Pelo menos 1 número
# - Pelo menos 1 letra maiúscula
# Retorna (True/False, lista_de_erros)

print("\n💡 Dica: Testes são a sua REDE DE SEGURANÇA. Se você quebrar algo, eles gritam imediatamente!")
