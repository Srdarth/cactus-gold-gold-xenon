#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 30 — Deploy, boas práticas e próximos passos
==================================================
Como levar seu código do "funciona no meu PC" para produção.
"""

print("=" * 60)
print("EXEMPLO DA AULA 30: Deploy e boas práticas")
print("=" * 60)

# --- 1. Checklist de qualidade antes de deployar ---
print("\n--- ✅ 1. CHECKLIST DE QUALIDADE ---")
checklist = """
🔹 CÓDIGO
   [ ] Nomes claros de variáveis e funções
   [ ] Funções pequenas e com um propósito só
   [ ] Sem código duplicado (DRY)
   [ ] Comentários explicam POR QUÊ, não O QUÊ
   [ ] Tipagem (type hints) onde faz sentido
   [ ] Sem print() em produção → use logging

🔹 TESTES
   [ ] Testes unitários para funções críticas
   [ ] pytest rodando e todos passando
   [ ] Testa casos normais, de borda e de erro
   [ ] Cobertura razoável (>70% para código crítico)

🔹 DEPENDÊNCIAS
   [ ] requirements.txt com versões pinadas
   [ ] venv isolado por projeto
   [ ] .venv/ no .gitignore

🔹 SEGURANÇA
   [ ] Nenhuma senha/token hardcoded no código
   [ ] Variáveis de ambiente para segredos
   [ ] Dependências atualizadas (pip-audit)
   [ ] Inputs validados (nunca confie no usuário)
   [ ] SQL parametrizado (nunca concatene strings)

🔹 ESTRUTURA DE PROJETO
   meu_projeto/
   ├── .venv/               (ignorado no git)
   ├── src/                 (código fonte)
   │   ├── __init__.py
   │   ├── main.py
   │   ├── utils.py
   │   └── db.py
   ├── tests/               (testes)
   │   ├── test_main.py
   │   └── test_utils.py
   ├── data/                (dados, se pequenos)
   ├── docs/                (documentação)
   ├── requirements.txt
   ├── README.md
   ├── .gitignore
   └── .env.example         (exemplo de variáveis de ambiente)
"""
print(checklist)

# --- 2. Variáveis de ambiente (nunca hardcode segredos!) ---
print("\n--- 🔐 2. Variáveis de ambiente ---")
exemplo_env = """
# ===== Salve como .env (NÃO COMITAR NO GIT!) =====
# Banco de dados
DB_HOST=localhost
DB_PORT=5432
DB_USER=eds_admin
DB_PASSWORD=sua_senha_super_segura_aqui

# APIs
API_KEY_CHATGPT=sk-xxxxxxxxxxxxxxxxxxxxxxxx
API_KEY_GOOGLE=abc123def456

# Aplicação
DEBUG=True
SECRET_KEY=chave_aleatoria_muito_longa_e_segura
"""
print(exemplo_env)

print("Como usar no Python:")
codigo_env = '''
# pip install python-dotenv
from dotenv import load_dotenv
import os

load_dotenv()  # carrega o arquivo .env

db_user = os.getenv("DB_USER")
db_password = os.getenv("DB_PASSWORD")
api_key = os.getenv("API_KEY_CHATGPT")

# Para OBRIGAR uma variável:
secret = os.environ["SECRET_KEY"]  # levanta KeyError se faltar
'''
print(codigo_env)

print(".gitignore deve conter:")
print("  .env")
print("  .venv/")
print("  __pycache__/")
print("  *.pyc")
print("  logs/")

# --- 3. Opções de Deploy ---
print("\n--- 🚀 3. OPÇÕES DE DEPLOY ---")
opcoes = """
📌 PARA APIs WEB (FastAPI/Flask):
   • Render.com     → fácil, free tier bom
   • Railway.app    → ótimo developer experience
   • Fly.io         → deploy com Docker
   • Vercel         → serverless (ótimo para funções)
   • AWS EC2/Lambda → escala grande, mais complexo

📌 PARA SCRIPTS/AUTOMAÇÃO:
   • GitHub Actions → agendar cron jobs grátis
   • PythonAnywhere → hospedar scripts Python
   • VPS (DigitalOcean, Hetzner) → controle total

📌 PARA BIBLIOTECAS/PACOTES:
   • PyPI → pip install seu_pacote

📌 PARA APLICATIVOS DESKTOP:
   • PyInstaller → .exe / .app
   • cx_Freeze → alternativa
   • Nuitka → compila para C (mais rápido)
"""
print(opcoes)

# --- 4. Docker básico ---
print("\n--- 🐳 4. Docker em 1 minuto ---")
dockerfile = """
# ===== Dockerfile (FastAPI exemplo) =====
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY src/ .

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
"""
print(dockerfile)
print("Comandos:")
print("  docker build -t minha-api .")
print("  docker run -p 8000:8000 minha-api")

# --- 5. Próximos passos na jornada Python ---
print("\n--- 🛤️ 5. PRÓXIMOS PASSOS ---")
jornada = """
↗️  APROFUNDE:
   • Padrões de projeto (Design Patterns)
   • Arquitetura limpa / Hexagonal
   • Domain-Driven Design (DDD)
   • Bancos relacionais avançados (PostgreSQL)
   • Bancos NoSQL (MongoDB, Redis)
   • Mensageria (RabbitMQ, Kafka)

↗️  ESPECIALIZE-SE:
   • IA / Machine Learning → pandas, numpy, scikit-learn, PyTorch
   • Dados → pandas, SQLAlchemy, Airflow, dbt
   • Web → FastAPI avançado, Django, autenticação, cache
   • Automação → Playwright/Selenium, PyAutoGUI
   • Segurança → criptografia, OAuth2, JWT

↗️  FERRAMENTAS:
   • Git avançado (rebase, cherry-pick, bisect)
   • CI/CD (GitHub Actions, GitLab CI)
   • Monitoramento (Prometheus, Grafana, Sentry)
   • Docker / Kubernetes
   • Poetry / PDM (gerenciamento de dependências moderno)
"""
print(jornada)

# --- 6. Filosofia Python ---
print("\n--- 🐍 6. O ZEN DO PYTHON ---")
import this

# --- DESAFIO FINAL ---
# Pegue um dos seus projetos pessoais e:
# 1. Organize na estrutura padrão (src/, tests/, docs/)
# 2. Escreva pelo menos 3 testes com pytest
# 3. Crie um requirements.txt com versões pinadas
# 4. Crie um .env.example e coloque .env no .gitignore
# 5. Escreva um README.md decente explicando: o que é, como instalar, como rodar, como testar

print("\n💡 Dica final: O melhor programador não é o que sabe mais recursos. É o que resolve PROBLEMAS com código limpo, testado e sustentável. 🚀")
