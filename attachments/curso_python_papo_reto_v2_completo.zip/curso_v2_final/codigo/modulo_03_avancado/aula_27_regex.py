#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 27 — Expressões regulares (Regex)
=======================================
Busca padrões complexos em texto de forma poderosa.
"""

import re

print("=" * 60)
print("EXEMPLO DA AULA 27: Regex")
print("=" * 60)

# Metacaracteres essenciais:
# .  = qualquer caractere (exceto nova linha)
# ^  = início da string/linha
# $  = fim da string/linha
# *  = 0 ou mais vezes
# +  = 1 ou mais vezes
# ?  = 0 ou 1 vez (opcional)
# {n,m} = entre n e m vezes
# [] = conjunto de caracteres: [a-z], [0-9], [aeiou]
# [^] = NÃO é do conjunto
# () = grupo de captura
# |  = OU
# \d = dígito [0-9], \w = palavra [a-zA-Z0-9_], \s = espaço, \b = borda de palavra
# \  = escapa metacaracteres: \. = ponto literal

texto_exemplo = """
Contatos EDS:
- Edson: edson@eddydigital.com.br, (21) 98765-4321, CPF 123.456.789-00
- Isabella: isabella.creator@eds.io, 11 99999-8888, CPF 987.654.321-00
- Suporte: suporte@eddydigital.com, (11) 3000-1234
Site: https://www.eddydigital.com.br
Lançamento: 2026-09-22
Valores: R$ 27,00 e R$ 199,90 e R$ 1.250,00
"""

print("Texto de exemplo:\n" + texto_exemplo)

# 1. Encontrar emails
print("\n--- 1. Emails encontrados ---")
padrao_email = r'[\w.-]+@[\w-]+\.[\w.-]+'
emails = re.findall(padrao_email, texto_exemplo)
for email in emails:
    print(f"  📧 {email}")

# 2. Encontrar telefones (formatos variados)
print("\n--- 2. Telefones encontrados ---")
padrao_tel = r'\(?\d{2}\)?\s?\d{4,5}[-.\s]?\d{4}'
telefones = re.findall(padrao_tel, texto_exemplo)
for tel in telefones:
    print(f"  📞 {tel}")

# 3. Encontrar CPFs
print("\n--- 3. CPFs encontrados ---")
padrao_cpf = r'\d{3}\.\d{3}\.\d{3}-\d{2}'
cpfs = re.findall(padrao_cpf, texto_exemplo)
for cpf in cpfs:
    print(f"  🆔 {cpf}")

# 4. Encontrar valores em Reais
print("\n--- 4. Valores monetários ---")
padrao_valor = r'R\$\s?[\d.]+,\d{2}'
valores = re.findall(padrao_valor, texto_exemplo)
for val in valores:
    print(f"  💰 {val}")

# 5. Encontrar URLs
print("\n--- 5. URLs ---")
padrao_url = r'https?://[\w.-]+(?:\.[\w.-]+)+[\w./?=&%-]*'
urls = re.findall(padrao_url, texto_exemplo)
for url in urls:
    print(f"  🔗 {url}")

# 6. Encontrar datas ISO
print("\n--- 6. Datas (AAAA-MM-DD) ---")
padrao_data = r'(\d{4})-(\d{2})-(\d{2})'
datas = re.findall(padrao_data, texto_exemplo)
for ano, mes, dia in datas:
    print(f"  📅 Dia {dia}/{mes}/{ano}")

# 7. Substituir com regex
print("\n--- 7. Substituição: mascarar CPFs ---")
texto_mascarado = re.sub(padrao_cpf, '***.***.***-**', texto_exemplo)
print("  CPFs mascarados no texto!")

# 8. Validar formatos (match = do início ao fim)
print("\n--- 8. Validação de formato ---")
def validar_email(email):
    padrao = r'^[\w.-]+@[\w-]+\.[\w.-]+$'
    return bool(re.match(padrao, email))

testes_email = ["edson@eds.io", "invalido@", "@dominio.com", "isabella.creator@eds.io"]
for email in testes_email:
    status = "✅ Válido" if validar_email(email) else "❌ Inválido"
    print(f"  {status} | {email}")

# 9. Compilar para performance (usar muitas vezes)
print("\n--- 9. re.compile — performance ---")
regex_compilada = re.compile(padrao_email, re.IGNORECASE)
resultado = regex_compilada.findall("Contato: SUPORTE@EDS.IO e contato@eddydigital.COM")
print(f"  Com IGNORECASE: {resultado}")

# --- DESAFIO ---
# Crie uma função que extrai todos os números de um texto e retorna como lista de inteiros.
# Crie um validador de senha forte: mínimo 8 caracteres, pelo menos 1 maiúscula, 1 minúscula, 1 número, 1 especial.

print("\n💡 Dica: Regex é poderosa mas pode ficar ILEGÍVEL. Comente, teste e use ferramentas como regex101.com!")
