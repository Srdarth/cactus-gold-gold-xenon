#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 28 — Concorrência e paralelismo
======================================
Faça mais coisas AO MESMO TEMPO: threading, asyncio, multiprocessing.
"""

import time
import threading
import asyncio
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

print("=" * 60)
print("EXEMPLO DA AULA 28: Concorrência")
print("=" * 60)

# Tarefa simulada (I/O bound = espera muito, usa pouco CPU)
def tarefa_io(nome, segundos):
    print(f"  ⏳ {nome} começando ({segundos}s)...")
    time.sleep(segundos)  # simula espera: rede, disco, banco
    print(f"  ✅ {nome} terminou!")
    return f"{nome}-ok"

# --- 1. SEQUENCIAL (um de cada vez) ---
print("\n--- 1. SEQUENCIAL (base para comparação) ---")
inicio = time.perf_counter()
tarefa_io("A", 2)
tarefa_io("B", 2)
tarefa_io("C", 2)
tempo_seq = time.perf_counter() - inicio
print(f"⏱️  Tempo total: {tempo_seq:.2f}s (esperado ~6s)")

# --- 2. THREADING (I/O bound, GIL liberado durante espera) ---
print("\n--- 2. THREADING ---")
inicio = time.perf_counter()

threads = []
for i, seg in enumerate([2, 2, 2], 1):
    t = threading.Thread(target=tarefa_io, args=(f"Tarefa-{i}", seg))
    threads.append(t)
    t.start()

for t in threads:
    t.join()

tempo_thread = time.perf_counter() - inicio
print(f"⏱️  Tempo total: {tempo_thread:.2f}s (esperado ~2s)")

# --- 3. ThreadPoolExecutor (mais moderno) ---
print("\n--- 3. ThreadPoolExecutor ---")
inicio = time.perf_counter()

with ThreadPoolExecutor(max_workers=3) as executor:
    futuros = [
        executor.submit(tarefa_io, f"Pool-{i}", 2)
        for i in range(1, 4)
    ]
    resultados = [f.result() for f in futuros]

print(f"  Resultados: {resultados}")
tempo_pool = time.perf_counter() - inicio
print(f"⏱️  Tempo total: {tempo_pool:.2f}s")

# --- 4. ASYNCIO (cooperativo, single-thread) ---
print("\n--- 4. ASYNCIO / async / await ---")

async def tarefa_async(nome, segundos):
    print(f"  ⏳ {nome} começando ({segundos}s)...")
    await asyncio.sleep(segundos)
    print(f"  ✅ {nome} terminou!")
    return f"{nome}-ok"

async def main_async():
    inicio = time.perf_counter()
    
    # Roda TODAS ao mesmo tempo
    tarefas = [
        tarefa_async(f"Async-{i}", 2)
        for i in range(1, 4)
    ]
    resultados = await asyncio.gather(*tarefas)
    
    tempo = time.perf_counter() - inicio
    print(f"  Resultados: {resultados}")
    print(f"⏱️  Tempo total: {tempo:.2f}s")

# Rodar o loop async
try:
    asyncio.run(main_async())
except RuntimeError:
    print("  (asyncio não rodou neste ambiente — funciona em script normal)")

# --- 5. MULTIPROCESSING (CPU bound = usa muito processador) ---
print("\n--- 5. MULTIPROCESSING (para CPU pesado) ---")
print("""
Quando usar CADA um:

🧵 THREADING / ASYNCIO → I/O BOUND
   • Espera por rede, banco, disco, API
   • Muitas tarefas esperando AO MESMO TEMPO
   • Exemplo: baixar 100 URLs, consultar banco

⚙️ MULTIPROCESSING → CPU BOUND
   • Cálculos pesados, processamento de imagem/dados
   • Usa VÁRIOS núcleos do CPU
   • Bypassa o GIL (Global Interpreter Lock)
   • Exemplo: processar 1 milhão de linhas, renderizar

📌 Regra de ouro:
   I/O bound   → threading / asyncio  (mais leve, mais rápido para esperas)
   CPU bound   → multiprocessing     (mais pesado, usa múltiplos cores)
""")

def calcular_pesado(n):
    """Função que usa CPU (não tem espera)."""
    total = 0
    for i in range(n):
        total += i ** 2
    return total

print("  (exemplo: para cálculos pesados, use ProcessPoolExecutor)")
print("  with ProcessPoolExecutor() as ex:")
print("      resultados = list(ex.map(calcular_pesado, [10_000_000]*4))")

# --- DESAFIO ---
# Use ThreadPoolExecutor para baixar 5 URLs diferentes AO MESMO TEMPO usando requests.
# Compare o tempo com a versão sequencial.

print("\n💡 Dica: Concorrência = múltiplas tarefas PROGREDINDO. Paralelismo = múltiplas tarefas RODANDO AO MESMO TEMPO.")
