#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 26 — Automação: arquivos, pastas e processos
==================================================
Faça o Python trabalhar por você — automatize tarefas chatas.
"""

import os
import shutil
import subprocess
from pathlib import Path
from datetime import datetime

print("=" * 60)
print("EXEMPLO DA AULA 26: Automação")
print("=" * 60)

# Criando pasta de teste
pasta_teste = Path("_automacao_teste")
pasta_teste.mkdir(exist_ok=True)

# 1. Listar e filtrar arquivos
print("\n--- 1. Explorando arquivos com Pathlib ---")
print(f"\nArquivos na pasta atual (últimos 10):")
arquivos = sorted(Path(".").glob("*.py"))
for arq in arquivos[-10:]:
    tamanho = arq.stat().st_size
    modificado = datetime.fromtimestamp(arq.stat().st_mtime).strftime("%d/%m %H:%M")
    print(f"  📄 {arq.name:40s} {tamanho:>8,} bytes  {modificado}")

# 2. Criar estrutura de pastas automaticamente
print("\n--- 2. Criando estrutura de pastas ---")
estrutura = pasta_teste / "projeto_novo"
subpastas = ["src", "docs", "tests", "data/entrada", "data/saida", "config"]

for sub in subpastas:
    caminho = estrutura / sub
    caminho.mkdir(parents=True, exist_ok=True)
    print(f"  ✅ {caminho}")

# 3. Renomear arquivos em lote (estilo NeverLost simplificado)
print("\n--- 3. Renomeando arquivos em lote ---")
pasta_para_renomear = pasta_teste / "fotos_baguncadas"
pasta_para_renomear.mkdir(exist_ok=True)

# Criando arquivos de exemplo "bagunçados"
nomes_originais = [
    "foto  (1).jpg",
    "FOTO FINAL!!.png",
    "img 2026-01-05.PNG",
    "print tela  final  .jpg",
    "  arquivo   espacos  .txt",
]
for nome in nomes_originais:
    (pasta_para_renomear / nome).touch()

print("  Antes:")
for arq in sorted(pasta_para_renomear.iterdir()):
    print(f"    '{arq.name}'")

# Renomeando: limpa espaços, lowercase, underscores
print("\n  Depois:")
for i, arq in enumerate(sorted(pasta_para_renomear.iterdir()), 1):
    if arq.is_file():
        # Limpa nome: espaços duplicados → um, espaços → _, lowercase
        nome_limpo = "_".join(arq.stem.split()).lower()
        novo_nome = f"imagem_{i:03d}_{nome_limpo}{arq.suffix.lower()}"
        novo_caminho = arq.with_name(novo_nome)
        arq.rename(novo_caminho)
        print(f"    '{novo_nome}'")

# 4. Copiar e mover arquivos
print("\n--- 4. Copiando arquivos ---")
origem = pasta_para_renomear
destino = pasta_teste / "backup_fotos"
destino.mkdir(exist_ok=True)

for arq in origem.iterdir():
    if arq.is_file():
        shutil.copy2(arq, destino / arq.name)  # copy2 preserva metadados
print(f"  ✅ Copiados {len(list(destino.iterdir()))} arquivos para backup")

# 5. Compactar em ZIP
print("\n--- 5. Compactando em ZIP ---")
caminho_zip = shutil.make_archive(
    base_name=str(pasta_teste / "backup_completo"),
    format="zip",
    root_dir=str(pasta_teste / "backup_fotos")
)
print(f"  ✅ ZIP criado: {caminho_zip}")
print(f"  Tamanho: {Path(caminho_zip).stat().st_size:,} bytes")

# 6. Rodar comandos do sistema
print("\n--- 6. Rodando processos externos ---")
try:
    resultado = subprocess.run(
        ["python", "--version"],
        capture_output=True,
        text=True,
        timeout=5
    )
    print(f"  Comando: python --version")
    print(f"  Saída:   {resultado.stdout.strip()}")
    print(f"  Código:  {resultado.returncode}")
except Exception as e:
    print(f"  ⚠️  Não foi possível rodar: {e}")

# 7. Encontrar arquivos duplicados por tamanho
print("\n--- 7. Detector simples de duplicatas ---")
arquivos_por_tamanho = {}
for arq in Path(".").rglob("*.py"):
    try:
        tam = arq.stat().st_size
        arquivos_por_tamanho.setdefault(tam, []).append(arq.name)
    except:
        pass

duplicatas = {tam: nomes for tam, nomes in arquivos_por_tamanho.items() if len(nomes) > 1}
if duplicatas:
    print("  Possíveis duplicatas (mesmo tamanho):")
    for tam, nomes in sorted(duplicatas.items(), reverse=True)[:3]:
        print(f"    {tam:>8,} bytes → {', '.join(nomes[:3])}")
else:
    print("  Nenhuma duplicata suspeita encontrada.")

# --- DESAFIO ---
# Crie um organizador automático que:
# 1. Lê uma pasta "Downloads"
# 2. Move arquivos para subpastas por extensão:
#    - Imagens (.jpg, .png, .gif) → imagens/
#    - Documentos (.pdf, .doc, .txt) → documentos/
#    - Vídeos (.mp4, .avi) → videos/
#    - Outros → outros/

print("\n💡 Dica: Pathlib = moderno e legível. shutil = operações de alto nível. subprocess = poder do sistema!")
