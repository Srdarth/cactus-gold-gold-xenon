#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 22 — Requisições HTTP com requests
=======================================
Como seu programa conversa com a internet e APIs.
"""

print("=" * 60)
print("EXEMPLO DA AULA 22: HTTP e requests")
print("=" * 60)

print("📌 Primeiro instale: pip install requests\n")

# Verificando se requests está disponível
try:
    import requests
    TEM_REQUESTS = True
except ImportError:
    TEM_REQUESTS = False
    print("⚠️  requests não instalado. Mostrando apenas conceitos e exemplos.\n")

# --- Conceitos HTTP básicos ---
print("--- CONCEITOS HTTP ---")
print("""
Métodos principais:
  GET    → Pegar dados (não muda nada no servidor)
  POST   → Enviar dados (criar algo novo)
  PUT    → Atualizar algo existente
  DELETE → Apagar algo
  PATCH  → Atualizar parcialmente

Códigos de status:
  2xx → SUCESSO (200 OK, 201 Created)
  3xx → REDIRECIONAMENTO
  4xx → ERRO DO CLIENTE (400 Bad Request, 401 Unauthorized, 404 Not Found)
  5xx → ERRO DO SERVIDOR (500 Internal Server Error)
""")

if TEM_REQUESTS:
    # 1. GET simples
    print("--- 1. GET: pegando dados de uma API ---")
    try:
        resposta = requests.get("https://jsonplaceholder.typicode.com/posts/1", timeout=5)
        print(f"  Status: {resposta.status_code}")
        print(f"  OK? {resposta.ok}")
        
        if resposta.status_code == 200:
            dados = resposta.json()
            print(f"\n  Título: {dados['title'][:60]}...")
            print(f"  Corpo:  {dados['body'][:80]}...")
    except requests.exceptions.RequestException as e:
        print(f"  ❌ Erro de conexão: {e}")

    # 2. GET com parâmetros de query
    print("\n--- 2. GET com parâmetros ---")
    try:
        params = {"userId": 1, "_limit": 3}
        r = requests.get("https://jsonplaceholder.typicode.com/posts", params=params, timeout=5)
        print(f"  URL final: {r.url}")
        posts = r.json()
        for p in posts:
            print(f"  Post #{p['id']}: {p['title'][:50]}...")
    except requests.exceptions.RequestException as e:
        print(f"  ❌ Erro: {e}")

    # 3. POST: enviando dados
    print("\n--- 3. POST: criando recurso ---")
    try:
        payload = {
            "title": "Isabella OS v2.0",
            "body": "Lançamento do produto digital",
            "userId": 1
        }
        headers = {"Content-Type": "application/json"}
        r = requests.post(
            "https://jsonplaceholder.typicode.com/posts",
            json=payload,
            headers=headers,
            timeout=5
        )
        print(f"  Status: {r.status_code} (Created = 201 esperado)")
        print(f"  ID gerado: {r.json().get('id')}")
    except requests.exceptions.RequestException as e:
        print(f"  ❌ Erro: {e}")

    # 4. Tratamento de erros
    print("\n--- 4. Tratamento de erros ---")
    urls_para_testar = [
        "https://jsonplaceholder.typicode.com/posts/999999",  # não existe
        "https://httpstat.us/500",  # erro servidor
        "https://jsonplaceholder.typicode.com/posts/1",  # existe
    ]
    
    for url in urls_para_testar:
        try:
            r = requests.get(url, timeout=5)
            r.raise_for_status()  # levanta exceção se 4xx ou 5xx
            print(f"  ✅ {url} → {r.status_code}")
        except requests.exceptions.HTTPError as e:
            print(f"  ❌ HTTP {url} → {e}")
        except requests.exceptions.RequestException as e:
            print(f"  ❌ Conexão {url} → {e}")

    # 5. Sessão (reutiliza conexão, cookies, etc.)
    print("\n--- 5. Session: reutilizando conexão ---")
    with requests.Session() as sessao:
        sessao.headers.update({"User-Agent": "CursoPythonEDS/1.0"})
        
        for i in range(1, 4):
            r = sessao.get(f"https://jsonplaceholder.typicode.com/comments/{i}", timeout=5)
            if r.ok:
                comentario = r.json()
                print(f"  Comentário {i}: {comentario['email']}")

# --- DESAFIO ---
# Use a API pública do GitHub: https://api.github.com/users/{usuario}
# Peça um nome de usuário ao usuário e mostre:
# nome, bio, quantidade de repositórios públicos, seguidores, seguindo.

print("\n💡 Dica: requests.get() = pegar. .json() = converter resposta para dicionário. .raise_for_status() = erro automático!")
