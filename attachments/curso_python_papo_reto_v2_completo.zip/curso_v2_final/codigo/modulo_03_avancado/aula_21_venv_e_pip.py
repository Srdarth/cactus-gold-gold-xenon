#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 21 — Ambientes virtuais (venv) e dependências
====================================================
Como isolar projetos e gerenciar bibliotecas de terceiros.
"""

import sys
import subprocess

print("=" * 60)
print("EXEMPLO DA AULA 21: venv e pip")
print("=" * 60)

print("\n📌 CONCEITOS FUNDAMENTAIS:")
print("""
Problema:
  Projeto A precisa requests==2.28
  Projeto B precisa requests==2.31
  Sem isolamento, eles BRIGAM!

Solução: venv (ambiente virtual)
  Cada projeto tem suas PRÓPRIAS bibliotecas.
  Nada interfere em nada.
""")

print("--- COMANDOS ESSENCIAIS (rodar no terminal) ---")
print("""
1️⃣  CRIAR ambiente virtual:
    Windows:  py -m venv .venv
    Linux/Mac: python3 -m venv .venv

2️⃣  ATIVAR ambiente:
    Windows CMD:      .venv\\Scripts\\activate.bat
    Windows PowerShell: .venv\\Scripts\\Activate.ps1
    Linux/Mac:        source .venv/bin/activate

    ✅ Quando ativado, aparece (.venv) no início do prompt!

3️⃣  INSTALAR pacotes:
    pip install requests          # última versão
    pip install requests==2.31.0   # versão exata
    pip install 'requests>=2.30'   # versão mínima
    pip install -r requirements.txt  # de um arquivo

4️⃣  SALVAR dependências:
    pip freeze > requirements.txt

5️⃣  DESATIVAR:
    deactivate

6️⃣  VER o que está instalado:
    pip list
    pip show requests
""")

# --- Verificando o ambiente atual ---
print(f"\n--- Ambiente Python atual ---")
print(f"  Executável: {sys.executable}")
print(f"  Versão: {sys.version.split()[0]}")
print(f"  Caminho dos pacotes: {sys.path[-1] if sys.path else 'n/a'}")

# --- requirements.txt EXEMPLO ---
print("\n--- Exemplo de requirements.txt ---")
exemplo_requirements = """# Produção
fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic==2.5.0
requests==2.31.0

# Desenvolvimento
pytest==7.4.3
black==23.11.0
ruff==0.1.8
"""
print(exemplo_requirements)

# --- Boas práticas ---
print("\n--- ✅ BOAS PRÁTICAS ---")
print("""
• Sempre crie um .venv POR PROJETO
• Adicione a pasta .venv/ no .gitignore
• Sempre commite requirements.txt
• Use pip-tools ou poetry para projetos maiores
• Nunca instale pacotes GLOBALMENTE sem necessidade
""")

# --- ❌ ERROS COMUNS ---
print("\n--- ❌ ERROS COMUNS ---")
print("""
1. "pip install funciona mas o código não encontra o pacote"
   → Você instalou GLOBALMENTE mas está rodando com o venv ativado (ou vice-versa)

2. "No module named 'xyz'"
   → Verifique se o venv está ATIVADO e se o pacote foi instalado lá

3. "Funciona no meu PC"
   → Falta commitar requirements.txt com versões pinadas
""")

# --- DESAFIO ---
# Crie um projeto novo:
# 1. Crie uma pasta
# 2. Crie e ative o venv
# 3. Instale requests e pytest
# 4. Gere o requirements.txt
# 5. Desative e delete o .venv
# 6. Recrie o .venv e instale tudo de novo com: pip install -r requirements.txt

print("\n💡 Dica: .venv = caixa de areia isolada. NUNCA comite a pasta .venv no git!")
