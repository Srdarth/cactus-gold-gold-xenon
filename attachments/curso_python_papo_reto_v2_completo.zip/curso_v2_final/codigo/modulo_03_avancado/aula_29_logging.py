#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 29 — Logging: registre tudo que acontece
=============================================
Substitua print() por logs profissionais — debug, info, warning, error, critical.
"""

import logging
from pathlib import Path

print("=" * 60)
print("EXEMPLO DA AULA 29: Logging")
print("=" * 60)

# Níveis de log (ordem de severidade):
# DEBUG    = 10  (detalhes para desenvolvimento)
# INFO     = 20  (informação geral, funcionamento normal)
# WARNING  = 30  (algo inesperado mas não quebrou)
# ERROR    = 40  (falha em alguma operação)
# CRITICAL = 50  (falha grave, programa pode parar)

# --- 1. Configuração BÁSICA ---
print("\n--- 1. Logging básico ---")
logging.basicConfig(
    level=logging.DEBUG,  # mostra tudo a partir deste nível
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%H:%M:%S"
)

logging.debug("Detalhe técnico: variável x = 42")
logging.info("Sistema iniciado com sucesso")
logging.warning("Uso de memória acima de 80%")
logging.error("Falha ao conectar no banco de dados")
logging.critical("Sistema fora do ar!")

# --- 2. Configuração COMPLETA: arquivo + console ---
print("\n--- 2. Log em arquivo + console com formatação rica ---")

# Resetar configuração anterior
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# Criar logger personalizado
logger = logging.getLogger("EDS")
logger.setLevel(logging.DEBUG)
logger.propagate = False

# Formato detalhado
formato = logging.Formatter(
    "%(asctime)s | %(levelname)-8s | %(name)s | %(module)s:%(lineno)d | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# Handler 1: Console (mostra INFO ou superior)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(formato)

# Handler 2: Arquivo (mostra TUDO incluindo DEBUG)
arquivo_log = Path("_sistema_eds.log")
arquivo_handler = logging.FileHandler(arquivo_log, encoding="utf-8")
arquivo_handler.setLevel(logging.DEBUG)
arquivo_handler.setFormatter(formato)

# Handler 3: Arquivo separado só para ERROS
arquivo_erros = logging.FileHandler("_erros_eds.log", encoding="utf-8")
arquivo_erros.setLevel(logging.ERROR)
arquivo_erros.setFormatter(formato)

# Juntar tudo
logger.addHandler(console_handler)
logger.addHandler(arquivo_handler)
logger.addHandler(arquivo_erros)

# Usando o logger
logger.debug("🔧 Inicializando módulos...")
logger.info("🚀 Aplicação EDS iniciada")
logger.info("📦 Carregados 15 módulos")
logger.warning("⚠️  API externa com latência alta (350ms)")
logger.error("❌ Falha ao processar pagamento #12345")
logger.critical("🔥 Banco de dados principal indisponível!")

# Log com exceção (try/except)
logger.info("\n--- 3. Log de exceção ---")
try:
    1 / 0
except ZeroDivisionError:
    logger.exception("💥 Erro durante cálculo matemático")
    # logger.exception = ERROR + stacktrace automático

print(f"\n✅ Arquivos de log criados:")
print(f"   📄 {arquivo_log} ({arquivo_log.stat().st_size} bytes)")
print(f"   📄 {arquivo_erros} ({arquivo_erros.stat().st_size} bytes)")

# --- 4. Boas práticas ---
print("\n--- ✅ BOAS PRÁTICAS ---")
print("""
• NÃO use print() em produção — use logging
• Use o nível CERTO: debug/info/warning/error/critical
• Logue contexto: qual usuário, qual operação, qual ID
• logger.exception() dentro de except = stacktrace automático
• Rotação de logs: use logging.handlers.RotatingFileHandler para não crescer infinito
• Logs estruturados (JSON): biblioteca structlog para produção grande
""")

# --- 5. O que NÃO logar ---
print("\n--- ⛔ NUNCA LOGUE ---")
print("""
• Senhas e tokens de API
• Dados pessoais sensíveis (CPF, RG, cartão)
• Dados financeiros completos
• Payloads gigantes (logue só o essencial)
""")

# --- DESAFIO ---
# Crie um decorador @logar_chamada que registra:
# - nome da função chamada
# - argumentos recebidos
# - valor retornado
# - tempo de execução
# - se houve exceção

print("\n💡 Dica: print() = para desenvolvedor. logging = para produção e manutenção!")
