#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 23 — Banco de dados SQLite
================================
Banco de dados relacional que vem EMBUTIDO no Python — sem instalar nada!
"""

import sqlite3
from pathlib import Path

print("=" * 60)
print("EXEMPLO DA AULA 23: SQLite")
print("=" * 60)

# Apagando banco anterior se existir para teste limpo
db_arquivo = Path("loja_eds.db")
db_arquivo.unlink(missing_ok=True)

# 1. Conectar (cria o arquivo se não existir)
print("\n--- 1. Conectando e criando tabelas ---")
conn = sqlite3.connect(db_arquivo)
conn.row_factory = sqlite3.Row  # permite acessar colunas por nome!
cursor = conn.cursor()

# Criação de tabelas
cursor.execute("""
CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL UNIQUE
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    preco REAL NOT NULL,
    estoque INTEGER DEFAULT 0,
    categoria_id INTEGER,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
)
""")

conn.commit()
print("✅ Tabelas criadas!")

# 2. Inserir dados
print("\n--- 2. Inserindo dados ---")
# Forma SEGURA: use ? para evitar SQL Injection!
categorias = [("Software",), ("Utilitário",), ("Educação",)]
cursor.executemany("INSERT INTO categorias (nome) VALUES (?)", categorias)

produtos = [
    ("Isabella OS", 27.00, 999, 1),
    ("NeverLost", 19.90, 500, 2),
    ("Curso Python V2", 47.00, 200, 3),
    ("Curso IA Avançada", 97.00, 100, 3),
]
cursor.executemany("""
INSERT INTO produtos (nome, preco, estoque, categoria_id)
VALUES (?, ?, ?, ?)
""", produtos)

conn.commit()
print(f"✅ Inseridas {cursor.rowcount} linhas!")

# 3. Consultar dados
print("\n--- 3. Consultando produtos ---")
cursor.execute("SELECT * FROM produtos WHERE preco > ? ORDER BY preco DESC", (30,))
for linha in cursor.fetchall():
    print(f"  #{linha['id']} {linha['nome']:25s} R${linha['preco']:.2f}  Estoque: {linha['estoque']}")

# 4. JOIN entre tabelas
print("\n--- 4. JOIN: produtos com suas categorias ---")
cursor.execute("""
SELECT p.nome as produto, p.preco, c.nome as categoria
FROM produtos p
JOIN categorias c ON p.categoria_id = c.id
ORDER BY c.nome, p.nome
""")
for linha in cursor.fetchall():
    print(f"  [{linha['categoria']:12s}] {linha['produto']:20s} R${linha['preco']:.2f}")

# 5. Atualizar dados
print("\n--- 5. Atualizando estoque ---")
novo_estoque = 800
produto_id = 1
cursor.execute("UPDATE produtos SET estoque = ? WHERE id = ?", (novo_estoque, produto_id))
conn.commit()
print(f"✅ Produto {produto_id} atualizado. Linhas afetadas: {cursor.rowcount}")

# Verificando
cursor.execute("SELECT nome, estoque FROM produtos WHERE id = ?", (produto_id,))
prod = cursor.fetchone()
print(f"  Confirmação: {prod['nome']} → estoque = {prod['estoque']}")

# 6. Deletar dados
print("\n--- 6. Deletando (com cuidado!) ---")
# cursor.execute("DELETE FROM produtos WHERE id = ?", (999,))
# conn.commit()
# print(f"Linhas deletadas: {cursor.rowcount}")
print("  (comentado para segurança — descomente se quiser testar)")

# 7. Funções agregadas
print("\n--- 7. Estatísticas ---")
cursor.execute("""
SELECT
    COUNT(*) as total_produtos,
    AVG(preco) as preco_medio,
    MIN(preco) as mais_barato,
    MAX(preco) as mais_caro,
    SUM(estoque) as estoque_total
FROM produtos
""")
estat = cursor.fetchone()
print(f"  Total produtos:    {estat['total_produtos']}")
print(f"  Preço médio:       R${estat['preco_medio']:.2f}")
print(f"  Mais barato:       R${estat['mais_barato']:.2f}")
print(f"  Mais caro:         R${estat['mais_caro']:.2f}")
print(f"  Estoque total:     {estat['estoque_total']} unidades")

# 8. Gerenciador de contexto (with)
print("\n--- 8. Com 'with' — commit automático ---")
with sqlite3.connect(db_arquivo) as conn2:
    conn2.row_factory = sqlite3.Row
    cur = conn2.cursor()
    cur.execute("INSERT INTO categorias (nome) VALUES (?)", ("Marketing",))
    # commit automático ao sair do with se não houver erro
    # rollback automático se houver exceção

conn.close()

# --- DESAFIO ---
# Crie um banco de contatos:
# - Tabela contatos (id, nome, telefone, email, favorito BOOLEAN)
# - Insira 5 contatos
# - Liste só os favoritos
# - Busque por nome parcial (use LIKE '%texto%')
# - Atualize o telefone de um contato

print("\n💡 Dica: SQLite = arquivo .db, zero configuração. Sempre use ? para valores — NUNCA concatene strings!")
