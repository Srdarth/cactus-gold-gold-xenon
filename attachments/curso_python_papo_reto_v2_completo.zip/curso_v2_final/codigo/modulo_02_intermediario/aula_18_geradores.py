#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 18 — Geradores e iteradores
=================================
Economize memória: gere dados SOB DEMANDA, não tudo de uma vez.
"""

print("=" * 60)
print("EXEMPLO DA AULA 18: Geradores")
print("=" * 60)

# Problema: lista com 1 MILHÃO de números usa MUITA memória
# Solução: gerador produz um número de cada vez

# 1. Gerador com yield
print("\n--- 1. Gerador com yield ---")
def contador(maximo):
    """Gera números de 1 até maximo, um por vez."""
    n = 1
    while n <= maximo:
        yield n  # PAUSA aqui, retorna n, continua daqui na próxima chamada
        n += 1

# Usando como iterável
for numero in contador(5):
    print(f"  {numero}", end=" ")
print()

# Pegando valores um por um
gen = contador(3)
print(f"\nPrimeiro: {next(gen)}")
print(f"Segundo:  {next(gen)}")
print(f"Terceiro: {next(gen)}")
try:
    next(gen)
except StopIteration:
    print("✅ Fim do gerador!")

# 2. Comparação de memória
print("\n--- 2. Lista vs Gerador (1 milhão de itens) ---")
import sys

lista_milhao = list(range(1_000_001))
tamanho_lista = sys.getsizeof(lista_milhao)
print(f"Lista de 1M:    {tamanho_lista:>10,} bytes ({tamanho_lista/1024/1024:.1f} MB)")

def gerador_milhao():
    for n in range(1_000_001):
        yield n

gen_milhao = gerador_milhao()
tamanho_gen = sys.getsizeof(gen_milhao)
print(f"Gerador de 1M:  {tamanho_gen:>10,} bytes ({tamanho_gen/1024:.1f} KB)")
print(f"Economia: {tamanho_lista / tamanho_gen:.0f}x menos memória!")

# 3. Generator expression (compreensão com parênteses)
print("\n--- 3. Generator expression ---")
quadrados_gen = (n ** 2 for n in range(10))
print(f"Tipo: {type(quadrados_gen).__name__}")
print(f"Valores: {list(quadrados_gen)}")

# Soma sem criar lista na memória
soma_quadrados = sum(n ** 2 for n in range(1_000_001))
print(f"Soma dos quadrados de 0 a 1M: {soma_quadrados:,}")

# 4. Caso de uso real: ler arquivo linha por linha
print("\n--- 4. Lendo arquivo com gerador ---")
def ler_arquivo_linhas(caminho):
    with open(caminho, "r", encoding="utf-8") as f:
        for linha in f:
            yield linha.strip()

# Criamos um arquivo de teste
with open("_teste_grande.txt", "w") as f:
    for i in range(100):
        f.write(f"Linha {i}: dados de exemplo\n")

# Processamos linha por linha (mesmo que o arquivo tenha GBs!)
total_caracteres = 0
for linha in ler_arquivo_linhas("_teste_grande.txt"):
    total_caracteres += len(linha)
print(f"Total de caracteres no arquivo: {total_caracteres:,}")

# 5. Pipelines de geradores
print("\n--- 5. Pipeline de geradores ---")
def numeros():
    for n in range(1, 21):
        yield n

def pares(gen):
    for n in gen:
        if n % 2 == 0:
            yield n

def dobrados(gen):
    for n in gen:
        yield n * 2

resultado = list(dobrados(pares(numeros())))
print(f"Números 1-20 → pares → dobrados: {resultado}")

# --- DESAFIO ---
# Crie um gerador que produz a sequência de Fibonacci infinitamente.
# Use next() para pegar os primeiros 15 termos.

print("\n💡 Dica: yield = 'produza e PARE'. Perfeito para dados grandes ou infinitos!")
