#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 17 — Funções avançadas: args, kwargs, lambda
===================================================
Funções mais flexíveis e poderosas.
"""

print("=" * 60)
print("EXEMPLO DA AULA 17: Funções avançadas")
print("=" * 60)

# 1. *args — número VARIÁVEL de argumentos posicionais
print("\n--- 1. *args ---")
def somar_tudo(*numeros):
    print(f"  args recebidos: {numeros} (tipo: {type(numeros).__name__})")
    return sum(numeros)

print(f"Soma 1+2: {somar_tudo(1, 2)}")
print(f"Soma 1+2+3+4+5: {somar_tudo(1, 2, 3, 4, 5)}")
print(f"Soma vazia: {somar_tudo()}")

def cadastrar_pessoa(nome, *caracteristicas):
    print(f"\n  {nome} tem: {', '.join(caracteristicas)}")

cadastrar_pessoa("Isabella", "criativa", "tecnológica", "carioca", "22 anos")

# 2. **kwargs — número VARIÁVEL de argumentos NOMEADOS
print("\n--- 2. **kwargs ---")
def exibir_dados(**dados):
    print(f"  kwargs recebidos: {dados} (tipo: {type(dados).__name__})")
    for chave, valor in dados.items():
        print(f"    {chave}: {valor}")

exibir_dados(nome="Isabella", idade=22, cidade="RJ", ativa=True)

# 3. Ordem correta dos parâmetros
print("\n--- 3. Ordem: padrão → *args → **kwargs ---")
def pedido(cliente, *itens, **detalhes):
    total = sum(itens)
    print(f"  Cliente: {cliente}")
    print(f"  Itens: R${' + R$'.join(str(i) for i in itens)} = R${total}")
    for k, v in detalhes.items():
        print(f"  {k}: {v}")

pedido("Maria", 49.90, 29.90, 19.90, pagamento="cartão", entrega="retirada")

# 4. Desempacotando listas/dicts com * e **
print("\n--- 4. Desempacotando ---")
valores = [10, 20, 30]
print(f"Lista: {valores}")
print(f"Desempacotada: {somar_tudo(*valores)}")  # = somar_tudo(10, 20, 30)

dados = {"nome": "João", "idade": 30, "cidade": "SP"}
exibir_dados(**dados)  # = exibir_dados(nome="João", idade=30, cidade="SP")

# 5. Lambda — funções anônimas de uma linha
print("\n--- 5. Lambda ---")
quadrado = lambda x: x ** 2
print(f"quadrado(5) = {quadrado(5)}")

multiplicar = lambda a, b: a * b
print(f"multiplicar(3, 4) = {multiplicar(3, 4)}")

# Útil com map, filter, sorted
numeros = [3, 1, 4, 1, 5, 9, 2, 6]
print(f"\nOriginal: {numeros}")
print(f"map(quadrado): {list(map(lambda x: x**2, numeros))}")
print(f"filter(pares): {list(filter(lambda x: x % 2 == 0, numeros))}")

pessoas = [("Ana", 25), ("Bruno", 30), ("Carla", 22)]
pessoas_ordenadas = sorted(pessoas, key=lambda p: p[1])  # ordena por idade
print(f"Ordenado por idade: {pessoas_ordenadas}")

# --- DESAFIO ---
# Crie uma função que recebe *args e retorna a média.
# Use sorted + lambda para ordenar uma lista de dicionários de produtos por preço.

print("\n💡 Dica: *args = tupla, **kwargs = dicionário. lambda = função rápida de uma linha.")
