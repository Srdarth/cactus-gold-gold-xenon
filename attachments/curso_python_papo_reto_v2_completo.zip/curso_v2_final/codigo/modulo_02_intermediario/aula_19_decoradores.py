#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 19 — Decoradores
=======================
Modifique o comportamento de funções sem alterar seu código.
"""

import time
from functools import wraps

print("=" * 60)
print("EXEMPLO DA AULA 19: Decoradores")
print("=" * 60)

# 1. Decorador SIMPLES: medir tempo
print("\n--- 1. Decorador @medir_tempo ---")
def medir_tempo(funcao):
    @wraps(funcao)  # preserva nome e docstring da função original
    def envelope(*args, **kwargs):
        inicio = time.perf_counter()
        resultado = funcao(*args, **kwargs)
        fim = time.perf_counter()
        print(f"  ⏱️  {funcao.__name__} demorou {(fim - inicio) * 1000:.2f}ms")
        return resultado
    return envelope

@medir_tempo
def calcular_soma(n):
    """Soma todos os números de 1 a n."""
    return sum(range(1, n + 1))

@medir_tempo
def dormir(segundos):
    time.sleep(segundos)
    return "acordei"

resultado = calcular_soma(1_000_000)
print(f"  Resultado soma: {resultado:,}")
dormir(0.1)

# 2. Decorador com PARÂMETROS
print("\n--- 2. Decorador @repetir(n) ---")
def repetir(vezes):
    def decorador(funcao):
        @wraps(funcao)
        def envelope(*args, **kwargs):
            resultados = []
            for _ in range(vezes):
                resultados.append(funcao(*args, **kwargs))
            return resultados
        return envelope
    return decorador

@repetir(3)
def dizer_ola(nome):
    mensagem = f"Olá, {nome}!"
    print(f"  {mensagem}")
    return mensagem

resultados = dizer_ola("Isabella")
print(f"  Retornos: {resultados}")

# 3. Decorador para autenticação/verificação
print("\n--- 3. Decorador @requer_login ---")
USUARIO_LOGADO = {"logado": False, "nome": None}

def requer_login(funcao):
    @wraps(funcao)
    def envelope(*args, **kwargs):
        if not USUARIO_LOGADO["logado"]:
            print("  🔒 ACESSO NEGADO: faça login primeiro!")
            return None
        return funcao(*args, **kwargs)
    return envelope

@requer_login
def ver_dados_sensiveis():
    return "DADOS SECRETOS: EDS fatura R$100k/mês"

print(f"  Sem login: {ver_dados_sensiveis()}")

USUARIO_LOGADO["logado"] = True
USUARIO_LOGADO["nome"] = "Edson"
print(f"  Com login: {ver_dados_sensiveis()}")

# 4. Empilhando decoradores
print("\n--- 4. Múltiplos decoradores ---")
def maiusculo(funcao):
    @wraps(funcao)
    def envelope(*args, **kwargs):
        resultado = funcao(*args, **kwargs)
        return resultado.upper()
    return envelope

def comemorar(funcao):
    @wraps(funcao)
    def envelope(*args, **kwargs):
        resultado = funcao(*args, **kwargs)
        return f"🎉 {resultado} 🎉"
    return envelope

@comemorar
@maiusculo
def saudacao(nome):
    return f"Feliz aniversário, {nome}"

print(f"  {saudacao('Isabella')}")

# --- DESAFIO ---
# Crie um decorador @cache que armazena resultados de funções.
# Se a função for chamada com os mesmos argumentos, retorna do cache sem rodar de novo.

print("\n💡 Dica: Decorador = função que recebe uma função e retorna OUTRA função. @ = açúcar sintático!")
