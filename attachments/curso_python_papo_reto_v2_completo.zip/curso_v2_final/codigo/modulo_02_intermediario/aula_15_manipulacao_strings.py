#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 15 — Manipulação de strings
=================================
Strings são listas de caracteres com superpoderes.
"""

print("=" * 60)
print("EXEMPLO DA AULA 15: Strings")
print("=" * 60)

texto = "  EddY Digital Solutions — Criando o futuro digital  "

print(f"\nOriginal: '{texto}'")
print(f"Tamanho: {len(texto)} caracteres")

# Fatiamento (como listas!)
print(f"\nPrimeiros 4 caracteres: '{texto[:4]}'")
print(f"Últimos 8 caracteres: '{texto[-8:]}'")
print(f"Do índice 5 ao 12: '{texto[5:12]}'")
print(f"Invertido: '{texto[::-1]}'")

# Métodos de transformação
print(f"\nMaiúsculas: '{texto.upper()}'")
print(f"Minúsculas: '{texto.lower()}'")
print(f"Título:     '{texto.title()}'")
print(f"Capitalize: '{texto.capitalize()}'")
print(f"Swap case:  '{texto.swapcase()}'")
print(f"Strip (tira espaços): '{texto.strip()}'")

# Busca e verificação
print(f"\nContém 'Digital'? {'Digital' in texto}")
print(f"Posição de 'Digital': {texto.find('Digital')}")
print(f"Conta 'i': {texto.count('i')}")
print(f"Começa com '  Edd'? {texto.startswith('  Edd')}")
print(f"Termina com '  '? {texto.endswith('  ')}")
print(f"Só tem espaços? {texto.isspace()}")
print(f"Só tem dígitos? '{texto.strip().isdigit()}'")
print(f"Só tem letras? 'Python'.isalpha() = {'Python'.isalpha()}")

# Substituição
novo = texto.replace("digital", "TECNOLÓGICO")
print(f"\nSubstituído: '{novo}'")

# Split e Join
frase = "Python é incrível para automação"
palavras = frase.split()  # quebra por espaços
print(f"\nSplit: {palavras}")
junto = " → ".join(palavras)
print(f"Join:  '{junto}'")

# Formatação de strings
nome = "Isabella"
idade = 22
print(f"\nf-string:  '{nome} tem {idade} anos e nasceu em {2026 - idade}'")
print(f"format():  '{} tem {} anos'.format(nome, idade)")
print(f"%-style:   '%s tem %d anos' % (nome, idade)")

# f-strings avançadas
preco = 49.9
print(f"\nPreço formatado: R${preco:.2f}")
print(f"Preço alinhado: R${preco:>8.2f}")
print(f"Percentual: {0.8572:.1%}")

# Caracteres especiais
print(f"\nNova linha: 'linha1\\nlinha2'")
print(f"Tab: 'col1\\tcol2\\tcol3'")
print(f"Aspas: 'ele disse \\\"olá\\\"'")

# --- DESAFIO ---
# Crie uma função que recebe uma frase e retorna True se for palíndromo.
# (ex: "A sacada da casa", "ovo", "socorram me subi no onibus em marrocos")

print("\n💡 Dica: Strings são IMUTÁVEIS — métodos retornam strings novas!")
