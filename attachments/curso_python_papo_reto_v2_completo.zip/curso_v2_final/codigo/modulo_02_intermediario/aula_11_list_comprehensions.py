#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 11 — Compreensões de lista (list comprehensions)
======================================================
Forma concisa e elegante de criar listas em uma linha.
"""

print("=" * 60)
print("EXEMPLO DA AULA 11: List Comprehensions")
print("=" * 60)

# Forma TRADICIONAL vs COMPREENSÃO
print("\n--- Quadrados de 1 a 10 ---")
# Tradicional
quadrados = []
for n in range(1, 11):
    quadrados.append(n ** 2)
print(f"Tradicional: {quadrados}")

# Compreensão
quadrados2 = [n ** 2 for n in range(1, 11)]
print(f"Compreensão: {quadrados2}")

# Com FILTRO (condição if)
print("\n--- Números pares de 1 a 20 ---")
pares = [n for n in range(1, 21) if n % 2 == 0]
print(f"Pares: {pares}")

# Com TRANSFORMAÇÃO condicional
print("\n--- Classificando números ---")
classificacao = ["par" if n % 2 == 0 else "ímpar" for n in range(1, 11)]
print(f"Classificação: {classificacao}")

# Aninhadas
print("\n--- Tabela de multiplicação 3x3 ---")
tabela = [[i * j for j in range(1, 4)] for i in range(1, 4)]
for linha in tabela:
    print(f"  {linha}")

# Com strings
print("\n--- Processando nomes ---")
nomes = ["  ana  ", "BRUNO", "carla", "  DANIEL  "]
limpos = [nome.strip().capitalize() for nome in nomes]
print(f"Original: {nomes}")
print(f"Limpos:    {limpos}")

# Dicionário por compreensão
print("\n--- Dict comprehension ---")
palavras = ["python", "java", "javascript", "go"]
tamanhos = {palavra: len(palavra) for palavra in palavras}
print(f"Tamanhos: {tamanhos}")

# Conjunto por compreensão
print("\n--- Set comprehension (remove duplicatas) ---")
numeros = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4]
unicos = {n for n in numeros}
print(f"Original: {numeros}")
print(f"Únicos:   {unicos}")

# --- DESAFIO ---
# Crie uma list comprehension que gera todos os números primos entre 2 e 50.
# Crie uma dict comprehension que mapeia números de 1 a 10 para seus fatoriais.

print("\n💡 Dica: [expressão for item in iterável if condição] — rápido e legível!")
