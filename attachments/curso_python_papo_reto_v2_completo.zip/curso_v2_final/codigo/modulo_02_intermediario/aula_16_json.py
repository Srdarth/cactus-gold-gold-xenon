#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 16 — JSON: dados estruturados
===================================
O formato universal de troca de dados entre sistemas.
"""

import json
from pathlib import Path

print("=" * 60)
print("EXEMPLO DA AULA 16: JSON")
print("=" * 60)

# Dicionário Python → JSON (serialização)
print("\n--- 1. Python → JSON ---")
isabella = {
    "nome": "Isabella",
    "idade": 22,
    "cidade": "Rio de Janeiro",
    "profissao": "Criadora Virtual",
    "hobbies": ["fotografia", "viagem", "música", "tecnologia"],
    "ativa": True,
    "projetos": {
        "isabella_os": "v2.0",
        "neverlost": "v1.0"
    },
    "altura": 1.68
}

json_texto = json.dumps(isabella, indent=2, ensure_ascii=False)
print(json_texto)

# JSON → Python (desserialização)
print("\n--- 2. JSON → Python ---")
dados = json.loads(json_texto)
print(f"Tipo: {type(dados)}")
print(f"Nome: {dados['nome']}")
print(f"Primeiro hobby: {dados['hobbies'][0]}")
print(f"Versão NeverLost: {dados['projetos']['neverlost']}")

# 3. Escrevendo JSON em arquivo
print("\n--- 3. Escrevendo arquivo JSON ---")
arquivo = Path("dados_isabella.json")
with open(arquivo, "w", encoding="utf-8") as f:
    json.dump(isabella, f, indent=2, ensure_ascii=False)
print(f"✅ Arquivo '{arquivo}' criado!")

# 4. Lendo JSON de arquivo
print("\n--- 4. Lendo arquivo JSON ---")
with open(arquivo, "r", encoding="utf-8") as f:
    dados_lidos = json.load(f)
print(f"Dados lidos com sucesso!")
print(f"Chaves: {list(dados_lidos.keys())}")

# 5. Lista de dicionários = banco de dados JSON
print("\n--- 5. Lista de produtos em JSON ---")
produtos = [
    {"id": 1, "nome": "Isabella OS", "preco": 27.00, "categoria": "software"},
    {"id": 2, "nome": "NeverLost", "preco": 19.90, "categoria": "utilitario"},
    {"id": 3, "nome": "Curso Python", "preco": 47.00, "categoria": "educacao"}
]

with open("produtos.json", "w", encoding="utf-8") as f:
    json.dump(produtos, f, indent=2, ensure_ascii=False)

# Filtrando
with open("produtos.json", "r", encoding="utf-8") as f:
    prods = json.load(f)

caros = [p for p in prods if p["preco"] > 20]
print(f"Produtos caros (>R$20): {[p['nome'] for p in caros]}")

# 6. Tratando tipos especiais
print("\n--- 6. Tipos não JSON ---")
# Python tem set, datetime, etc. JSON não tem.
dados_especiais = {"data": "2026-09-22", "numeros": [1, 2, 3]}  # use string para datas
print(json.dumps(dados_especiais, indent=2))

# --- DESAFIO ---
# Crie um programa que funciona como agenda:
# - Adiciona contato (nome, telefone, email)
# - Salva em contatos.json
# - Lista todos os contatos
# - Busca por nome

print("\n💡 Dica: JSON = texto. json.dumps = Python→texto. json.loads = texto→Python.")
