#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 20 — Gerenciadores de contexto (with)
===========================================
Como recursos são abertos e FECHADOS automaticamente.
"""

from contextlib import contextmanager
from pathlib import Path

print("=" * 60)
print("EXEMPLO DA AULA 20: Gerenciadores de contexto")
print("=" * 60)

# 1. O problema SEM 'with'
print("\n--- 1. SEM with (perigoso!) ---")
try:
    arquivo = open("exemplo_aula20.txt", "w")
    arquivo.write("linha 1\n")
    arquivo.write("linha 2\n")
    # Se der erro AQUI, o arquivo NUNCA fecha!
    raise Exception("Erro simulado!")
    arquivo.close()  # NUNCA chega aqui
except Exception as e:
    print(f"  Erro: {e}")
    print("  ⚠️  Arquivo pode ter ficado ABERTO!")

# 2. COM 'with' — seguro!
print("\n--- 2. COM with (seguro) ---")
with open("exemplo_aula20.txt", "w", encoding="utf-8") as arquivo:
    arquivo.write("escrito com segurança\n")
    arquivo.write("nunca ficará aberto!\n")
    # Mesmo que dê erro aqui, o arquivo FECHA automaticamente
print("  ✅ Arquivo foi FECHADO automaticamente!")

# 3. Criando seu próprio gerenciador com CLASSE
print("\n--- 3. Gerenciador por classe ---")
class ConexaoBanco:
    """Simula uma conexão com banco de dados."""
    
    def __init__(self, nome_banco):
        self.nome_banco = nome_banco
    
    def __enter__(self):
        """Executa ao entrar no 'with'."""
        print(f"  🔌 Conectando em '{self.nome_banco}'...")
        self.conectado = True
        return self  # o que vai para a variável depois de 'as'
    
    def __exit__(self, tipo_excecao, valor_excecao, traceback):
        """Executa ao SAIR do 'with' (mesmo com erro!)."""
        print(f"  🔌 Desconectando de '{self.nome_banco}'...")
        self.conectado = False
        if tipo_excecao is not None:
            print(f"  ⚠️  Houve erro: {valor_excecao}")
        # return True = suprime a exceção. Não faça isso a menos que saiba o que faz!
    
    def consultar(self, sql):
        if self.conectado:
            return f"RESULTADO de '{sql}': [dados, dados, dados]"
        raise ConnectionError("Não conectado!")


with ConexaoBanco("banco_eds") as db:
    print(f"  {db.consultar('SELECT * FROM clientes')}")
    # Mesmo se der erro aqui, __exit__ roda!

print("  ✅ Conexão garantidamente fechada!")

# 4. Gerenciador com @contextmanager (mais simples!)
print("\n--- 4. @contextmanager com yield ---")
@contextmanager
def diretorio_temporario(caminho):
    """Muda para um diretório e volta ao original depois."""
    import os
    diretorio_original = os.getcwd()
    print(f"  📂 Entrando em: {caminho}")
    os.makedirs(caminho, exist_ok=True)
    os.chdir(caminho)
    
    try:
        yield  # aqui fica o código do usuário
    finally:
        print(f"  📂 Voltando para: {diretorio_original}")
        os.chdir(diretorio_original)


import os
print(f"  Antes: {os.getcwd().split('/')[-1]}")

with diretorio_temporario("_pasta_temp_aula20"):
    print(f"  Durante: {os.getcwd().split('/')[-1]}")
    # Cria arquivos aqui...
    Path("arquivo_dentro.txt").write_text("estou dentro!")

print(f"  Depois: {os.getcwd().split('/')[-1]}")

# 5. Múltiplos contextos de uma vez
print("\n--- 5. Múltiplos with ---")
with open("exemplo_aula20.txt", "r") as entrada, open("_copia_aula20.txt", "w") as saida:
    for linha in entrada:
        saida.write(linha.upper())
print("  ✅ Arquivo copiado e convertido para MAIÚSCULAS!")

# --- DESAFIO ---
# Crie um gerenciador de contexto que mede o tempo de execução do bloco.
# Use com: with Timer() as t: ... e depois t.segundos mostra o tempo.

print("\n💡 Dica: __enter__ = setup, __exit__ = limpeza. 'with' = segurança garantida!")
