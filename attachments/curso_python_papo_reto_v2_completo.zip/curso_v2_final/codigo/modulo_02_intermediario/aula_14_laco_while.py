#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 14 — Laço while e repetição condicional
=============================================
Quando você NÃO sabe quantas vezes vai repetir.
"""

print("=" * 60)
print("EXEMPLO DA AULA 14: while")
print("=" * 60)

# 1. Contagem regressiva
print("\n--- 1. Contagem regressiva ---")
contador = 5
while contador > 0:
    print(f"  {contador}...")
    contador -= 1
print("  🚀 Lançamento!")

# 2. Validação de entrada (o usuário digita até acertar)
print("\n--- 2. Validação de senha ---")
senha_correta = "python123"
tentativas = 0
max_tentativas = 3

while tentativas < max_tentativas:
    senha = input("Digite a senha: ")
    tentativas += 1
    
    if senha == senha_correta:
        print(f"✅ Acesso liberado! (tentativa {tentativas})")
        break
    else:
        restantes = max_tentativas - tentativas
        if restantes > 0:
            print(f"❌ Senha errada. Restam {restantes} tentativas.")
else:
    # Executa se o while NÃO foi quebrado por break
    print("\n🔒 Acesso BLOQUEADO. Muitas tentativas.")

# 3. Menu interativo
print("\n--- 3. Menu interativo ---")
soma = 0
while True:  # loop infinito
    print("\nMENU:")
    print("  1 - Adicionar número")
    print("  2 - Ver soma")
    print("  0 - Sair")
    
    opcao = input("Escolha: ")
    
    if opcao == "1":
        try:
            n = float(input("Número: "))
            soma += n
            print(f"✅ Adicionado. Soma atual: {soma}")
        except ValueError:
            print("❌ Digite um número válido!")
    elif opcao == "2":
        print(f"📊 Soma total: {soma}")
    elif opcao == "0":
        print("👋 Saindo...")
        break
    else:
        print("❌ Opção inválida!")

# 4. continue vs break
print("\n--- 4. continue vs break ---")
for n in range(1, 11):
    if n % 2 == 0:
        continue  # PULA o resto e volta para o for
    if n == 7:
        break     # MATA o loop completamente
    print(f"  {n}")

# --- DESAFIO ---
# Crie o jogo "Adivinhe o número": computador escolhe 1-100, usuário tenta adivinhar.
# Dê dicas: "maior", "menor". Conte tentativas.

print("\n💡 Dica: while = 'enquanto'. Use break para sair e continue para pular.")
