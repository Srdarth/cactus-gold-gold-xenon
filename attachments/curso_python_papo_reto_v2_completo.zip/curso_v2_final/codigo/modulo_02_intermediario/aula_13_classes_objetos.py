#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 13 — Classes e objetos (POO básico)
==========================================
Como criar seus próprios tipos de dados com comportamento.
"""

print("=" * 60)
print("EXEMPLO DA AULA 13: Programação Orientada a Objetos")
print("=" * 60)

class Produto:
    """Representa um produto em estoque."""
    
    # Atributo de CLASSE (igual para todos)
    imposto = 0.18
    
    def __init__(self, nome, preco, quantidade=0):
        """Construtor — roda quando criamos um novo Produto."""
        # Atributos de INSTÂNCIA (cada objeto tem o seu)
        self.nome = nome
        self.preco = preco
        self.quantidade = quantidade
    
    def valor_total(self):
        """Método: calcula o valor total em estoque."""
        return self.preco * self.quantidade
    
    def preco_com_imposto(self):
        return self.preco * (1 + self.imposto)
    
    def adicionar_estoque(self, qtd):
        if qtd > 0:
            self.quantidade += qtd
            return True
        return False
    
    def __str__(self):
        """Representação em string (para print)."""
        return f"Produto(nome='{self.nome}', preco=R${self.preco:.2f}, qtd={self.quantidade})"


# --- CRIANDO OBJETOS ---
print("\n--- Criando produtos ---")
camiseta = Produto("Camiseta EDS", 49.90, 100)
caneca = Produto("Caneca Exclusivity", 29.90, 50)

print(camiseta)
print(caneca)

# Usando métodos
print(f"\nValor total em camisetas: R${camiseta.valor_total():.2f}")
print(f"Preço da caneca com imposto: R${caneca.preco_com_imposto():.2f}")

# Modificando atributos
camiseta.adicionar_estoque(50)
print(f"\nDepois de adicionar estoque: {camiseta.quantidade} unidades")

# Atributo de classe afeta todos
print(f"\nImposto atual: {Produto.imposto * 100:.0f}%")
Produto.imposto = 0.20  # muda para todos!
print(f"Novo imposto: {Produto.imposto * 100:.0f}%")
print(f"Preço camiseta agora: R${camiseta.preco_com_imposto():.2f}")

# --- HERANÇA ---
print("\n--- Herança: ProdutoDigital ---")
class ProdutoDigital(Produto):
    """Produto que não tem estoque físico."""
    
    def __init__(self, nome, preco, tamanho_arquivo_mb):
        super().__init__(nome, preco, quantidade=9999)  # infinito
        self.tamanho_arquivo_mb = tamanho_arquivo_mb
    
    def baixar(self):
        return f"📥 Baixando {self.nome} ({self.tamanho_arquivo_mb}MB)..."


ebook = ProdutoDigital("Isabella OS v2.0", 27.00, 5)
print(ebook)
print(ebook.baixar())

# --- DESAFIO ---
# Crie uma classe 'ContaBancaria' com: titular, saldo, numero.
# Métodos: depositar(valor), sacar(valor), transferir(outra_conta, valor).
# Trate saldo insuficiente com raise.

print("\n💡 Dica: class = molde. objeto = coisa feita do molde. self = 'eu mesmo'.")
