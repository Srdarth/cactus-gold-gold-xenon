#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Aula 12 — Arquivos CSV
=======================
Como ler e escrever dados tabulares (planilhas simples).
"""

import csv
from pathlib import Path

print("=" * 60)
print("EXEMPLO DA AULA 12: Arquivos CSV")
print("=" * 60)

dados_arquivo = Path("vendas_exemplo.csv")

# 1. ESCREVENDO CSV
print("\n--- 1. Escrevendo CSV ---")
cabecalho = ["produto", "quantidade", "preco_unitario", "categoria"]
linhas = [
    ["Camiseta", 50, 39.90, "Roupas"],
    ["Calça Jeans", 30, 89.90, "Roupas"],
    ["Tênis", 20, 199.90, "Calçados"],
    ["Boné", 40, 29.90, "Acessórios"],
    ["Relógio", 15, 299.90, "Acessórios"],
]

with open(dados_arquivo, "w", newline="", encoding="utf-8") as f:
    escritor = csv.writer(f, delimiter=",")
    escritor.writerow(cabecalho)
    escritor.writerows(linhas)
print(f"✅ CSV criado: {dados_arquivo}")

# 2. LENDO CSV com reader
print("\n--- 2. Lendo com csv.reader ---")
with open(dados_arquivo, "r", encoding="utf-8") as f:
    leitor = csv.reader(f)
    cabecalho_lido = next(leitor)  # pula cabeçalho
    print(f"Cabeçalho: {cabecalho_lido}")
    total_itens = 0
    for linha in leitor:
        produto, qtd, preco, cat = linha
        total_itens += int(qtd)
        print(f"  {produto:12s} | Qtd: {qtd:>3s} | R${preco} | {cat}")
    print(f"\nTotal de itens em estoque: {total_itens}")

# 3. LENDO CSV com DictReader (melhor!)
print("\n--- 3. Lendo com csv.DictReader ---")
faturamento_total = 0
with open(dados_arquivo, "r", encoding="utf-8") as f:
    leitor = csv.DictReader(f)
    for linha in leitor:
        qtd = int(linha["quantidade"])
        preco = float(linha["preco_unitario"])
        total = qtd * preco
        faturamento_total += total
        print(f"  {linha['produto']:12s} → Faturamento: R${total:.2f}")

print(f"\n💰 Faturamento total se vender tudo: R${faturamento_total:.2f}")

# 4. CSV com delimitador diferente (ponto e vírgula, comum no Brasil)
print("\n--- 4. CSV com ; ---")
with open("vendas_brasil.csv", "w", newline="", encoding="utf-8") as f:
    escritor = csv.writer(f, delimiter=";")
    escritor.writerow(["produto", "valor"])
    escritor.writerow(["Café", "4,50"])
print("✅ CSV com ';' criado!")

# --- DESAFIO ---
# Leia o CSV de vendas e crie um novo CSV só com produtos da categoria "Acessórios".
# Calcule o preço médio por categoria.

print("\n💡 Dica: Use DictReader — acessa por nome da coluna, não por posição!")
