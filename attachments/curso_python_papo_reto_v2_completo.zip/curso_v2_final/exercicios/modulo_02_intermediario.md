# Exercícios — Módulo 02 (Intermediario)

## Arquivos e dados

1. Ler um arquivo .txt e contar quantas linhas e palavras ele tem.
2. Salvar uma lista de dicionários em JSON e depois ler de volta.
3. Ler um CSV e calcular total e média de uma coluna numérica.
4. Escrever um script que varre uma pasta e gera um relatório CSV com nome do arquivo, extensão e tamanho.
5. Mini-projeto: organizador de arquivos por extensão (criar pastas e mover).
