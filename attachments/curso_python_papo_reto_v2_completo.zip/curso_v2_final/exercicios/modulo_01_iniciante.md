# Exercícios — Módulo 01 (Iniciante)

## Fundamentos

1. Faça um programa que peça nome e idade e diga quantos dias a pessoa já viveu (aproximação: idade*365).
2. Faça um validador simples de senha: mínimo 8 caracteres, precisa de 1 número.
3. Crie uma lista de tarefas (to-do) no terminal: adicionar, listar, remover pelo índice.
4. Crie um dicionário com 5 termos de programação e seus significados (pode ser em português).
5. Mini-projeto: calculadora com +, -, *, / e tratamento de erro.
