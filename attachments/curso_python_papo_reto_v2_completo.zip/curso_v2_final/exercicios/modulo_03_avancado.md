# Exercícios — Módulo 03 (Avancado)

## Backend e POO

1. Modelar uma classe `Produto` com nome, preço e método para aplicar desconto.
2. Criar um gerenciador de contexto (`with`) que mede tempo de execução (timer).
3. Implementar um generator que lê um arquivo grande linha a linha e filtra linhas com uma palavra-chave.
4. Subir uma API FastAPI com rota GET /ping e rota POST /eco que devolve o que recebeu.
5. Projeto final: CRUD simples de clientes (memória ou SQLite).
