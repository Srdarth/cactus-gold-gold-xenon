# Projeto 1 — Calculadora de bolso (Papo Reto)

## Objetivo
Criar uma calculadora no terminal com:
- +, -, *, /
- validação de entrada
- loop para repetir até o usuário sair

## Passo a passo
1. Leia a operação (`+ - * /`).
2. Leia dois números.
3. Valide:
   - operação válida
   - números válidos
   - divisão por zero
4. Mostre o resultado.
5. Pergunte se quer continuar.

## Dica de arquitetura
Faça funções pequenas:
- `ler_float()`
- `calcular(op, a, b)`
- `main()` (loop)

## Assinatura
Creation by Digital Specialist Edson Souza Leite, a work of Eddy Digital Solutions, Exclusivity ESL
