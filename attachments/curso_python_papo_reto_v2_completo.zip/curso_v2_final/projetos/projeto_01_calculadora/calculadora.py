"""Projeto 1 — Calculadora de bolso"""

def ler_float(msg: str) -> float:
    while True:
        txt = input(msg).strip().replace(",", ".")
        try:
            return float(txt)
        except ValueError:
            print("Número inválido. Tente de novo.")

def calcular(op: str, a: float, b: float) -> float:
    if op == "+":
        return a + b
    if op == "-":
        return a - b
    if op == "*":
        return a * b
    if op == "/":
        if b == 0:
            raise ZeroDivisionError("divisão por zero")
        return a / b
    raise ValueError("op inválida")

def main():
    print("Calculadora — digite 'sair' para encerrar")
    while True:
        op = input("Operação (+ - * /): ").strip()
        if op.lower() == "sair":
            break
        a = ler_float("a: ")
        b = ler_float("b: ")

        try:
            r = calcular(op, a, b)
        except Exception as e:
            print("Erro:", e)
            continue

        print("Resultado:", r)

if __name__ == "__main__":
    main()
