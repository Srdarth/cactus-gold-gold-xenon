from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, EmailStr
from pathlib import Path
import sqlite3
from typing import Optional, List

# ============================================================
# Projeto Final — Curso Python Papo Reto V2 (EDS | Exclusivity ESL)
# Mini API de Gerenciamento de Clientes + Produtos
# Assinatura: Creation by Digital Specialist Edson Souza Leite
# ============================================================

app = FastAPI(
    title="EDS — Mini Sistema Comercial",
    description="API de exemplo do projeto final do curso: FastAPI + SQLite + Pydantic",
    version="1.0.0",
    contact={"name": "Eddy Digital Solutions", "email": "contato@eddydigital.com"}
)

DB_PATH = Path(__file__).resolve().parent / "db.sqlite3"


def get_conn():
    """Cria conexão SQLite com row_factory para acesso por nome de coluna."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Inicializa as tabelas se não existirem."""
    with get_conn() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT UNIQUE,
                telefone TEXT,
                ativo BOOLEAN DEFAULT 1,
                criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                preco REAL NOT NULL,
                estoque INTEGER DEFAULT 0,
                categoria TEXT DEFAULT 'geral'
            )
        """)
        con.commit()


init_db()


# ============================================================
# MODELOS PYDANTIC (validação automática)
# ============================================================

class ClienteIn(BaseModel):
    nome: str
    email: Optional[EmailStr] = None
    telefone: Optional[str] = None
    ativo: bool = True


class ClienteOut(BaseModel):
    id: int
    nome: str
    email: Optional[str]
    telefone: Optional[str]
    ativo: bool
    criado_em: str


class ClienteAtualizacao(BaseModel):
    nome: Optional[str] = None
    email: Optional[EmailStr] = None
    telefone: Optional[str] = None
    ativo: Optional[bool] = None


class ProdutoIn(BaseModel):
    nome: str
    preco: float
    estoque: int = 0
    categoria: str = "geral"


class ProdutoOut(BaseModel):
    id: int
    nome: str
    preco: float
    estoque: int
    categoria: str


# ============================================================
# ROTAS — RAIZ
# ============================================================

@app.get("/", tags=["Raiz"])
def raiz():
    """Endpoint inicial — verifica se a API está no ar."""
    return {
        "mensagem": "API EDS funcionando!",
        "docs": "/docs (Swagger UI)",
        "redoc": "/redoc",
        "versao": "1.0.0"
    }


@app.get("/ping", tags=["Raiz"])
def ping():
    """Health check simples."""
    return {"ok": True, "servico": "mini-sistema-eds"}


# ============================================================
# ROTAS — CLIENTES
# ============================================================

@app.post("/clientes", response_model=ClienteOut, status_code=201, tags=["Clientes"])
def criar_cliente(cliente: ClienteIn):
    """Cria um novo cliente. Email é único."""
    with get_conn() as con:
        try:
            cur = con.execute(
                "INSERT INTO clientes (nome, email, telefone, ativo) VALUES (?, ?, ?, ?)",
                (cliente.nome, cliente.email, cliente.telefone, cliente.ativo)
            )
            con.commit()
            cliente_id = cur.lastrowid
        except sqlite3.IntegrityError:
            raise HTTPException(status_code=400, detail="Email já cadastrado")
    
    return obter_cliente(cliente_id)


@app.get("/clientes", response_model=List[ClienteOut], tags=["Clientes"])
def listar_clientes(apenas_ativos: bool = False, busca: Optional[str] = None):
    """Lista todos os clientes, com filtros opcionais."""
    query = "SELECT * FROM clientes WHERE 1=1"
    params = []
    
    if apenas_ativos:
        query += " AND ativo = 1"
    if busca:
        query += " AND (nome LIKE ? OR email LIKE ?)"
        params.extend([f"%{busca}%", f"%{busca}%"])
    
    query += " ORDER BY nome ASC"
    
    with get_conn() as con:
        rows = con.execute(query, params).fetchall()
    
    return [dict(r) for r in rows]


@app.get("/clientes/{cliente_id}", response_model=ClienteOut, tags=["Clientes"])
def obter_cliente(cliente_id: int):
    """Busca um cliente pelo ID. Retorna 404 se não existir."""
    with get_conn() as con:
        row = con.execute("SELECT * FROM clientes WHERE id = ?", (cliente_id,)).fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail=f"Cliente {cliente_id} não encontrado")
    
    return dict(row)


@app.put("/clientes/{cliente_id}", response_model=ClienteOut, tags=["Clientes"])
def atualizar_cliente(cliente_id: int, dados: ClienteAtualizacao):
    """Atualiza apenas os campos enviados."""
    cliente = obter_cliente(cliente_id)
    
    dados_dict = dados.model_dump(exclude_unset=True)
    if not dados_dict:
        return cliente
    
    campos = ", ".join(f"{k} = ?" for k in dados_dict.keys())
    valores = list(dados_dict.values()) + [cliente_id]
    
    with get_conn() as con:
        con.execute(f"UPDATE clientes SET {campos} WHERE id = ?", valores)
        con.commit()
    
    return obter_cliente(cliente_id)


@app.delete("/clientes/{cliente_id}", status_code=204, tags=["Clientes"])
def deletar_cliente(cliente_id: int):
    """Remove um cliente (hard delete)."""
    obter_cliente(cliente_id)  # verifica se existe
    
    with get_conn() as con:
        con.execute("DELETE FROM clientes WHERE id = ?", (cliente_id,))
        con.commit()


# ============================================================
# ROTAS — PRODUTOS
# ============================================================

@app.post("/produtos", response_model=ProdutoOut, status_code=201, tags=["Produtos"])
def criar_produto(produto: ProdutoIn):
    """Cria um novo produto."""
    with get_conn() as con:
        cur = con.execute(
            "INSERT INTO produtos (nome, preco, estoque, categoria) VALUES (?, ?, ?, ?)",
            (produto.nome, produto.preco, produto.estoque, produto.categoria)
        )
        con.commit()
        produto_id = cur.lastrowid
    
    return obter_produto(produto_id)


@app.get("/produtos", response_model=List[ProdutoOut], tags=["Produtos"])
def listar_produtos(categoria: Optional[str] = None, preco_max: Optional[float] = None):
    """Lista produtos com filtros opcionais."""
    query = "SELECT * FROM produtos WHERE 1=1"
    params = []
    
    if categoria:
        query += " AND categoria = ?"
        params.append(categoria)
    if preco_max is not None:
        query += " AND preco <= ?"
        params.append(preco_max)
    
    query += " ORDER BY nome ASC"
    
    with get_conn() as con:
        rows = con.execute(query, params).fetchall()
    
    return [dict(r) for r in rows]


@app.get("/produtos/{produto_id}", response_model=ProdutoOut, tags=["Produtos"])
def obter_produto(produto_id: int):
    """Busca um produto pelo ID."""
    with get_conn() as con:
        row = con.execute("SELECT * FROM produtos WHERE id = ?", (produto_id,)).fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail=f"Produto {produto_id} não encontrado")
    
    return dict(row)


@app.get("/estatisticas", tags=["Estatísticas"])
def estatisticas():
    """Mostra estatísticas gerais do sistema."""
    with get_conn() as con:
        total_clientes = con.execute("SELECT COUNT(*) FROM clientes").fetchone()[0]
        clientes_ativos = con.execute("SELECT COUNT(*) FROM clientes WHERE ativo = 1").fetchone()[0]
        total_produtos = con.execute("SELECT COUNT(*) FROM produtos").fetchone()[0]
        estoque_total = con.execute("SELECT COALESCE(SUM(estoque), 0) FROM produtos").fetchone()[0]
        preco_medio = con.execute("SELECT COALESCE(AVG(preco), 0) FROM produtos").fetchone()[0]
    
    return {
        "clientes": {
            "total": total_clientes,
            "ativos": clientes_ativos,
            "inativos": total_clientes - clientes_ativos
        },
        "produtos": {
            "total": total_produtos,
            "estoque_total": estoque_total,
            "preco_medio": round(preco_medio, 2)
        }
    }


# ============================================================
# EXECUÇÃO DIRETA
# ============================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
