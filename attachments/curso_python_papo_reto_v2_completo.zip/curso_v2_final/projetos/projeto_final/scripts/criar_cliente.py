"""Automação simples: criar cliente via API

Rode a API primeiro: uvicorn backend.app:app --reload
Depois:
    python scripts/criar_cliente.py
"""

import requests

API = "http://127.0.0.1:8000"

def main():
    nome = input("Nome: ")
    email = input("Email: ")
    r = requests.post(f"{API}/clientes", json={"nome": nome, "email": email}, timeout=10)
    print("status:", r.status_code)
    print(r.json())

if __name__ == "__main__":
    main()
