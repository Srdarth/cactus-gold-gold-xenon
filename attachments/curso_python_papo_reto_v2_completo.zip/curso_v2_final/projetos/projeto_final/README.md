# Projeto Final — Mini API + Automação (EDS)

## Visão
- Backend: FastAPI
- Banco: SQLite
- Frontend exemplo: um HTML simples chamando a API com `fetch()`

## Rodando (padrão)
1. Crie e ative um venv
2. Instale deps:
   - `pip install -r requirements.txt`
3. Rode:
   - `uvicorn backend.app:app --reload`
4. Abra:
   - `http://127.0.0.1:8000/docs`

## Estrutura
- `backend/` → API
- `frontend_exemplo.html` → exemplo de consumo com JS
- `scripts/` → automações que chamam a API

## Assinatura
Creation by Digital Specialist Edson Souza Leite, a work of Eddy Digital Solutions, Exclusivity ESL
