# Projeto 2 — Organizador de arquivos + relatório

## Objetivo
Você escolhe uma pasta, e o script:
1. cria subpastas por extensão (ex.: `png/`, `pdf/`, `txt/`)
2. move arquivos para a pasta correta
3. gera um relatório `relatorio.csv` com: nome, extensão, tamanho, destino

## Por que isso é um projeto “de verdade”?
Porque junta:
- `pathlib` (arquivos/pastas)
- loops e condicionais
- tratamento de erro
- CSV (relatório)
- organização em funções

## Assinatura
Creation by Digital Specialist Edson Souza Leite, a work of Eddy Digital Solutions, Exclusivity ESL
