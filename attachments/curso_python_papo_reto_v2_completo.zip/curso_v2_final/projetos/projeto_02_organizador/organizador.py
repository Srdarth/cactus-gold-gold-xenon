"""Projeto 2 — Organizador de arquivos + relatório"""

from pathlib import Path
import csv
import shutil

def organizar(pasta: Path, destino: Path) -> list[dict]:
    destino.mkdir(exist_ok=True)
    relatorio=[]
    for item in pasta.iterdir():
        if not item.is_file():
            continue
        ext = (item.suffix.lower().lstrip(".") or "sem_ext")
        pasta_ext = destino / ext
        pasta_ext.mkdir(exist_ok=True)
        novo = pasta_ext / item.name

        # evita sobrescrever
        if novo.exists():
            novo = pasta_ext / f"{item.stem}_copia{item.suffix}"

        shutil.move(str(item), str(novo))
        relatorio.append({
            "arquivo": item.name,
            "ext": ext,
            "tamanho_bytes": novo.stat().st_size,
            "destino": str(novo)
        })
    return relatorio

def salvar_csv(rows: list[dict], path: Path):
    with path.open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=["arquivo","ext","tamanho_bytes","destino"])
        w.writeheader()
        w.writerows(rows)

def main():
    origem = Path(input("Pasta origem: ").strip() or ".")
    destino = Path(input("Pasta destino (ex.: organizado): ").strip() or "organizado")
    rows = organizar(origem, destino)
    out = destino / "relatorio.csv"
    salvar_csv(rows, out)
    print("OK. Relatório em:", out.resolve())

if __name__ == "__main__":
    main()
