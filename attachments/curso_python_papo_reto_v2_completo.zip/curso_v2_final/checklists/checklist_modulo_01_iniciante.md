# Checklist — Módulo 01: Iniciante
## Aulas 01–10

### ✅ Conceitos dominados
- [ ] Entendo o que é interpretador Python e como ele executa código
- [ ] Sei usar variáveis e a função `input()`
- [ ] Entendo conversão de tipos (`int()`, `float()`, `str()`)
- [ ] Domino `if / elif / else` e operadores lógicos (`and`, `or`, `not`)
- [ ] Sei usar `for` com `range()` e para percorrer listas
- [ ] Domino listas: acessar, modificar, adicionar, remover, ordenar
- [ ] Crio e uso funções com parâmetros e `return`
- [ ] Sei ler e escrever arquivos com `with open()`
- [ ] Entendo dicionários: chave/valor, iteração, métodos
- [ ] Trato erros com `try / except / else / finally`
- [ ] Importo e uso módulos padrão (`math`, `random`, `datetime`, etc.)

### ⚠️ Erros comuns a evitar
- [ ] Não confundir `=` (atribuição) com `==` (comparação)
- [ ] Não esqueço que `input()` SEMPRE retorna string
- [ ] Não uso índices negativos sem querer
- [ ] Não esqueço de fechar arquivos (sempre uso `with open()`)
- [ ] Não capturo exceções genéricas `except:` sem especificar
- [ ] Não modifico listas enquanto percorro elas

### 🧠 Habilidade prática
- [ ] Consigo fazer um programa que pede dados ao usuário e toma decisões
- [ ] Consigo ler um CSV e calcular estatísticas simples
- [ ] Consigo organizar dados em listas e dicionários
- [ ] Consigo criar funções para evitar repetição de código
- [ ] Consigo tratar erros para o programa não "quebrar" feio

### 📝 Autoavaliação
- Conceitos: ___ / 10
- Prática: ___ / 5
- Nível de confiança: ___ %
