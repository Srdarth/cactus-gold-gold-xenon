# Checklist — Módulo 02: Intermediário
## Aulas 11–20

### ✅ Conceitos dominados
- [ ] Domino list comprehensions, dict comprehensions e set comprehensions
- [ ] Leio e escrevo arquivos CSV com `csv.reader` e `csv.DictReader`
- [ ] Entendo POO básica: classes, objetos, atributos, métodos, `__init__`, `self`
- [ ] Entendo herança e `super()`
- [ ] Uso `while` para repetição condicional e validação de entrada
- [ ] Diferenço `break` e `continue`
- [ ] Domino manipulação de strings: fatiamento, métodos, formatação
- [ ] Trabalho com JSON: `json.dumps`, `json.loads`, `json.dump`, `json.load`
- [ ] Uso `*args` e `**kwargs` em funções
- [ ] Crio funções `lambda` e uso com `map`/`filter`/`sorted`
- [ ] Entendo geradores e o benefício de `yield` vs listas
- [ ] Crio e uso decoradores simples
- [ ] Entendo gerenciadores de contexto (`with`) e crio os meus

### ⚠️ Erros comuns a evitar
- [ ] Não confundo list comprehension com sintaxe de tupla
- [ ] Não esqueço `newline=""` ao escrever CSV
- [ ] Não esqueço `self` como primeiro parâmetro de métodos
- [ ] Não crio loops `while` infinitos (sempre tem condição de saída)
- [ ] Não concateno strings em loops grandes (use `join`)
- [ ] Não trato JSON como string — sempre parseio
- [ ] Não uso geradores como se fossem listas (só percorrem uma vez!)

### 🧠 Habilidade prática
- [ ] Consigo transformar dados de CSV em JSON e vice-versa
- [ ] Consigo modelar um problema real com classes e objetos
- [ ] Consigo criar menus interativos com validação robusta
- [ ] Consigo extrair e transformar dados de texto complexo
- [ ] Consigo criar funções flexíveis que aceitam argumentos variáveis
- [ ] Consigo processar arquivos grandes sem estourar memória (geradores)

### 📝 Autoavaliação
- Conceitos: ___ / 10
- Prática: ___ / 6
- Nível de confiança: ___ %
