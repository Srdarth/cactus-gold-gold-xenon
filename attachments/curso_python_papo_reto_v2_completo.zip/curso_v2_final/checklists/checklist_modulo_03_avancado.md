# Checklist — Módulo 03: Avançado
## Aulas 21–30

### ✅ Conceitos dominados
- [ ] Crio e gerencio ambientes virtuais (`venv`) e uso `pip` corretamente
- [ ] Faço requisições HTTP com `requests`: GET, POST, parâmetros, headers, tratamento de erros
- [ ] Trabalho com SQLite: criar tabelas, CRUD, JOIN, funções agregadas
- [ ] Escrevo testes automatizados com `pytest`: asserts, parametrize, fixtures
- [ ] Crio APIs REST com FastAPI: rotas, modelos Pydantic, validação, documentação automática
- [ ] Automatizo tarefas do sistema: arquivos, pastas, compactação, subprocessos
- [ ] Uso expressões regulares (`re`) para buscar e validar padrões complexos
- [ ] Entendo quando usar threading vs asyncio vs multiprocessing
- [ ] Implemento logging profissional: níveis, handlers, formatação, arquivos separados
- [ ] Conheço boas práticas de deploy: estrutura de projeto, variáveis de ambiente, .gitignore, Docker, opções de hospedagem

### ⚠️ Erros comuns a evitar
- [ ] Não instalo pacotes globalmente — sempre uso `venv`
- [ ] Não concateno strings em SQL — sempre uso parâmetros (`?`)
- [ ] Não esqueço `status_code=201` em POST e `204` em DELETE
- [ ] Não uso regex para TUDO — às vezes métodos de string são mais simples e legíveis
- [ ] Não uso threading para CPU bound — uso multiprocessing
- [ ] Não deixo segredos hardcoded no código — uso variáveis de ambiente
- [ ] Não comito `.venv/`, `__pycache__/`, `.env` no git

### 🧠 Habilidade prática
- [ ] Consigo consumir qualquer API REST e tratar os dados
- [ ] Consigo criar uma API completa com FastAPI + SQLite + testes
- [ ] Consigo automatizar qualquer tarefa repetitiva do sistema operacional
- [ ] Consigo extrair informações estruturadas de textos bagunçados com regex
- [ ] Consigo deixar uma aplicação pronta para deploy profissional

### 🚀 Próximos passos
- [ ] Projeto completo real (sua ideia!)
- [ ] Estudar padrões de projeto
- [ ] Aprofundar em um nicho: IA / Dados / Web / Automação
- [ ] Contribuir em projetos open source

### 📝 Autoavaliação
- Conceitos: ___ / 10
- Prática: ___ / 5
- Nível de confiança: ___ %
