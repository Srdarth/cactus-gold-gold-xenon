# Checklist de estudo (EDS)

## Antes de começar uma aula
- [ ] Eu sei qual é o objetivo da aula
- [ ] Eu tenho um arquivo `.py` e um terminal aberto
- [ ] Eu sei onde estou (pasta do projeto)

## Depois de terminar uma aula
- [ ] Rodei o exemplo sem copiar/colar (ou reescrevi)
- [ ] Quebrei o código e consertei
- [ ] Escrevi um resumo de 5 linhas com minhas palavras
- [ ] Fiz pelo menos 2 exercícios

## Quando travar
- [ ] Li o erro inteiro (linha + mensagem)
- [ ] Eu consigo dizer: “o que o Python esperava?”
- [ ] Fiz um teste mínimo (um arquivo pequeno só com o pedaço problemático)
