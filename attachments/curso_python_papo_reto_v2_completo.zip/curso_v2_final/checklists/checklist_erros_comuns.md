# Erros comuns (e como sair rápido)

## “ModuleNotFoundError”
- Você está fora do venv?
- A biblioteca está instalada no venv certo?
- Você rodou `pip install ...` com o venv ativo?

## “FileNotFoundError”
- Você está na pasta correta?
- Use `Path(...).resolve()` para ver o caminho completo.

## “TypeError”
- Você está somando string com número?
- Lembre: `input()` sempre devolve `str`.
