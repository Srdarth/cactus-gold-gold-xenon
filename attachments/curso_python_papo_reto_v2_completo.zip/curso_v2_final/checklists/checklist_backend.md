# Checklist Backend (FastAPI)

- [ ] Sei explicar o que é HTTP (requisição/resposta)
- [ ] Sei o que é JSON e como ele vira dict em Python
- [ ] Sei o que é rota (endpoint)
- [ ] Sei diferença de GET vs POST
- [ ] Sei onde colocar validação (Pydantic)
- [ ] Sei onde persistir dados (SQLite)
