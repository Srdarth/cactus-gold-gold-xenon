# -*- coding: utf-8 -*-
"""
NeverLost v1.0 — One‑Click (Windows)
UI simples (Tkinter) para rodar o NeverLost sem CMD.

✅ 100% offline / read‑only
✅ Detecta discos automaticamente (SSD/HD) e pode incluir pendrives
✅ Você pode:
   - Rodar em "Todos os discos" (autodetect do core)
   - Ou marcar discos específicos (C:\, D:\, etc.)
✅ Gera os mesmos arquivos do core:
   - resumo.json
   - relatorio_mapa_do_caos.html
   - neverlost.db (incremental)
"""

from __future__ import annotations

import os
import sys
import threading
import queue
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Importa o core (NeverLost.py) na mesma pasta
try:
    import NeverLost as core
except Exception as e:
    raise SystemExit(f"Falha ao importar NeverLost.py (core). Erro: {e}")

# ----------------------------
# Utilidades Windows (drives)
# ----------------------------
def _windows_logical_drives():
    # preferimos reaproveitar a função do core, se existir
    if hasattr(core, "_windows_logical_drives"):
        return list(core._windows_logical_drives())
    # fallback
    try:
        import ctypes
        bitmask = ctypes.windll.kernel32.GetLogicalDrives()
        drives = []
        for i in range(26):
            if bitmask & (1 << i):
                drives.append(f"{chr(65+i)}:\\")
        return drives
    except Exception:
        return []

def _windows_drive_type(root: str) -> str:
    if hasattr(core, "_windows_drive_type"):
        return str(core._windows_drive_type(root))
    try:
        import ctypes
        DRIVE_TYPES = {0:"unknown",1:"no_root_dir",2:"removable",3:"fixed",4:"remote",5:"cdrom",6:"ramdisk"}
        t = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))
        return DRIVE_TYPES.get(int(t), "unknown")
    except Exception:
        return "unknown"

def list_drives(include_removable: bool):
    drives = []
    for d in _windows_logical_drives():
        t = _windows_drive_type(d)
        if t == "fixed" or (include_removable and t == "removable"):
            if Path(d).exists():
                drives.append((d, t))
    return drives

# ----------------------------
# Captura de logs (print)
# ----------------------------
class StdoutRedirector:
    def __init__(self, q: queue.Queue):
        self.q = q
    def write(self, s):
        if s:
            self.q.put(s)
    def flush(self):
        pass

# ----------------------------
# Runner em thread
# ----------------------------
def run_core_in_thread(args_list, log_q, on_done):
    def _target():
        old_argv = sys.argv[:]
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        try:
            sys.argv = ["NeverLost.py"] + args_list
            sys.stdout = StdoutRedirector(log_q)
            sys.stderr = StdoutRedirector(log_q)
            core.main()
            ok = True
        except SystemExit:
            # argparse pode chamar sys.exit
            ok = True
        except Exception as e:
            log_q.put(f"\n[ERRO] {e!r}\n")
            ok = False
        finally:
            sys.argv = old_argv
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            on_done(ok)
    t = threading.Thread(target=_target, daemon=True)
    t.start()

# ----------------------------
# UI
# ----------------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NeverLost — Mapa do Caos Digital (One‑Click)")
        self.geometry("860x620")
        self.minsize(820, 560)

        self.log_q = queue.Queue()
        self.running = False

        # Vars
        self.var_all = tk.BooleanVar(value=True)
        self.var_removable = tk.BooleanVar(value=False)
        self.var_out = tk.StringVar(value=str(Path.cwd() / "neverlost_output"))
        self.var_temp_warn = tk.DoubleVar(value=72.0)
        self.var_temp_hard = tk.DoubleVar(value=82.0)
        self.var_auto_window = tk.IntVar(value=30000)
        self.var_auto_target_ms = tk.DoubleVar(value=2.0)
        self.var_auto_max_sleep = tk.DoubleVar(value=0.12)

        self.drive_vars = {}  # "C:\" -> BooleanVar
        self._build()
        self._refresh_drives()
        self.after(80, self._poll_logs)

    def _build(self):
        pad = {"padx": 10, "pady": 8}

        top = ttk.Frame(self)
        top.pack(fill="x", **pad)

        title = ttk.Label(top, text="NeverLost — Mapa do Caos Digital", font=("Segoe UI", 16, "bold"))
        title.pack(anchor="w")

        sub = ttk.Label(top, text="100% offline • não move nada • gera um relatório HTML + um banco incremental (SQLite)")
        sub.pack(anchor="w")

        # Output
        outf = ttk.LabelFrame(self, text="Saída (onde o relatório + DB vão ficar)")
        outf.pack(fill="x", **pad)

        row = ttk.Frame(outf)
        row.pack(fill="x", padx=10, pady=8)
        ttk.Entry(row, textvariable=self.var_out).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Escolher…", command=self._choose_out).pack(side="left", padx=(8,0))

        # Drives
        df = ttk.LabelFrame(self, text="Discos / Roots")
        df.pack(fill="x", **pad)

        row2 = ttk.Frame(df)
        row2.pack(fill="x", padx=10, pady=(8,2))

        ttk.Checkbutton(row2, text="Iniciar análise em TODOS os discos automaticamente", variable=self.var_all, command=self._toggle_drive_list).pack(side="left")

        row3 = ttk.Frame(df)
        row3.pack(fill="x", padx=10, pady=(2,8))
        ttk.Checkbutton(row3, text="Incluir pendrives / removíveis (opcional)", variable=self.var_removable, command=self._refresh_drives).pack(side="left")
        ttk.Button(row3, text="Recarregar discos", command=self._refresh_drives).pack(side="right")

        self.drive_box = ttk.Frame(df)
        self.drive_box.pack(fill="x", padx=12, pady=(0,10))

        # Advanced
        af = ttk.LabelFrame(self, text="Desempenho e segurança (auto‑throttle)")
        af.pack(fill="x", **pad)

        g = ttk.Frame(af)
        g.pack(fill="x", padx=10, pady=8)

        def add_l(label, widget, col):
            ttk.Label(g, text=label).grid(row=0, column=col, sticky="w", padx=(0,6))
            widget.grid(row=1, column=col, sticky="we", padx=(0,12))
            g.columnconfigure(col, weight=1)

        add_l("Janela (arquivos)", ttk.Entry(g, textvariable=self.var_auto_window, width=10), 0)
        add_l("Alvo (ms/arq)", ttk.Entry(g, textvariable=self.var_auto_target_ms, width=10), 1)
        add_l("Sleep máx (s)", ttk.Entry(g, textvariable=self.var_auto_max_sleep, width=10), 2)
        add_l("Temp aviso (°C)", ttk.Entry(g, textvariable=self.var_temp_warn, width=10), 3)
        add_l("Temp hard (°C)", ttk.Entry(g, textvariable=self.var_temp_hard, width=10), 4)

        # Buttons
        bf = ttk.Frame(self)
        bf.pack(fill="x", **pad)

        self.btn_run = ttk.Button(bf, text="▶ Iniciar análise", command=self._run)
        self.btn_run.pack(side="left")

        ttk.Button(bf, text="Abrir pasta de saída", command=self._open_out).pack(side="left", padx=(8,0))

        ttk.Button(bf, text="Como funciona", command=self._help).pack(side="right")

        # Logs
        lf = ttk.LabelFrame(self, text="Log")
        lf.pack(fill="both", expand=True, **pad)

        self.txt = tk.Text(lf, wrap="word", font=("Consolas", 10))
        self.txt.pack(fill="both", expand=True, padx=8, pady=8)
        self.txt.insert("end", "Pronto. Clique em “Iniciar análise”.\n")
        self.txt.configure(state="disabled")

    def _choose_out(self):
        d = filedialog.askdirectory(title="Escolha a pasta de saída (relatórios + DB)")
        if d:
            self.var_out.set(d)

    def _open_out(self):
        p = Path(self.var_out.get())
        p.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(p))
        except Exception:
            messagebox.showinfo("Pasta", f"Pasta: {p}")

    def _help(self):
        msg = (
            "• O NeverLost NÃO move / NÃO apaga nada.\n"
            "• Ele varre os discos e cria um MAPA (DB + relatório HTML).\n\n"
            "Modo recomendado:\n"
            "1) Clique em Iniciar (Todos os discos).\n"
            "2) Abra o arquivo relatorio_mapa_do_caos.html na pasta de saída.\n\n"
            "Se quiser escolher discos:\n"
            "- Desmarque “Todos os discos” e marque os discos desejados.\n"
        )
        messagebox.showinfo("Como funciona", msg)

    def _toggle_drive_list(self):
        # habilita/desabilita checkboxes
        state = "disabled" if self.var_all.get() else "normal"
        for child in self.drive_box.winfo_children():
            try:
                child.configure(state=state)
            except Exception:
                pass

    def _refresh_drives(self):
        # limpa box
        for w in self.drive_box.winfo_children():
            w.destroy()
        self.drive_vars.clear()

        drives = list_drives(self.var_removable.get())
        if not drives:
            ttk.Label(self.drive_box, text="(Nenhum disco detectado — execute como Windows normal e tente “Recarregar discos”)").pack(anchor="w")
            return

        for d, t in drives:
            v = tk.BooleanVar(value=(t == "fixed"))
            self.drive_vars[d] = v
            cb = ttk.Checkbutton(self.drive_box, text=f"{d}  ({t})", variable=v)
            cb.pack(side="left", padx=(0,12))
        self._toggle_drive_list()

    def _append_log(self, s: str):
        self.txt.configure(state="normal")
        self.txt.insert("end", s)
        self.txt.see("end")
        self.txt.configure(state="disabled")

    def _poll_logs(self):
        try:
            while True:
                s = self.log_q.get_nowait()
                self._append_log(s)
        except queue.Empty:
            pass
        self.after(80, self._poll_logs)

    def _run(self):
        if self.running:
            return

        out_dir = Path(self.var_out.get()).expanduser()
        out_dir.mkdir(parents=True, exist_ok=True)

        args = ["--out", str(out_dir)]

        # autodetect ou roots
        if self.var_all.get():
            # não passa --roots => core autodetecta discos fixos (e removíveis se marcado)
            if self.var_removable.get():
                args.append("--include-removable")
        else:
            chosen = [d for d, v in self.drive_vars.items() if v.get()]
            if not chosen:
                messagebox.showwarning("Discos", "Marque pelo menos 1 disco, ou ative “Todos os discos”.")
                return
            args += ["--roots"] + chosen

        # auto throttle / temps
        args += ["--auto-window", str(int(self.var_auto_window.get()))]
        args += ["--auto-target-ms", str(float(self.var_auto_target_ms.get()))]
        args += ["--auto-max-sleep", str(float(self.var_auto_max_sleep.get()))]
        args += ["--temp-warn", str(float(self.var_temp_warn.get()))]
        args += ["--temp-hard", str(float(self.var_temp_hard.get()))]

        # UI state
        self.running = True
        self.btn_run.configure(state="disabled")
        self._append_log("\n=== INICIANDO NEVERLOST ===\n")
        self._append_log("Args: " + " ".join(args) + "\n\n")

        def _done(ok: bool):
            self.running = False
            self.btn_run.configure(state="normal")
            if ok:
                self._append_log("\n✅ Finalizado. Abra o HTML na pasta de saída.\n")
            else:
                self._append_log("\n❌ Terminou com erro. Copie o log acima e me mande.\n")

        run_core_in_thread(args, self.log_q, _done)

if __name__ == "__main__":
    # Tkinter no Windows gosta de DPI awareness
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    app = App()
    app.mainloop()
