@echo off
setlocal ENABLEDELAYEDEXPANSION

REM ==========================================================
REM NeverLost v1.0 — Build Windows EXE (One‑Click)
REM ==========================================================
REM Requisitos: Python 3.10+ instalado (com "py" no PATH)
REM O resultado sai em: dist\NeverLost.exe
REM ==========================================================

echo [NeverLost] Instalando/atualizando PyInstaller...
py -m pip install --upgrade pip >nul
py -m pip install --upgrade pyinstaller >nul

echo [NeverLost] Limpando builds antigos...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist NeverLost.spec del /q NeverLost.spec

echo [NeverLost] Gerando EXE (sem console)...
py -m PyInstaller --noconsole --onefile --name NeverLost NeverLost_UI.py

echo.
echo OK! EXE gerado em: dist\NeverLost.exe
echo Agora rode: make_release.bat  (para criar o ZIP final do Gumroad)
echo.
pause
