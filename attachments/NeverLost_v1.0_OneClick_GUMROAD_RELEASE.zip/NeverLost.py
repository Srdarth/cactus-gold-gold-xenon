# -*- coding: utf-8 -*-
"""
NeverLost — Mapa do Caos Digital (Offline / Read-only)
======================================================

O que é:
- Um "observador" local que VARRE seus discos e cria um mapa do seu caos (DB + relatório HTML).
- 100% offline, não move/apaga/renomeia nada. Só lê e indexa.

Por que existe:
- Antes de organizar, você precisa enxergar. NeverLost te dá o raio‑X do seu PC/HDs.

Compatibilidade:
- Windows (detecta drives automaticamente). Python 3.10+.
- Sem dependências externas.

Saídas:
- <out>/neverlost.db (SQLite)
- <out>/resumo.json
- <out>/relatorio_mapa_do_caos.html

Licença:
- Uso pessoal/comercial limitado (veja LICENSE.txt no pacote).
"""

from __future__ import annotations

import argparse
import ctypes
import datetime as _dt
import json
import os
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

# ----------------------------
# Windows: drives
# ----------------------------
def _windows_logical_drives() -> List[str]:
    """Retorna lista tipo ['C:\\', 'D:\\', ...]"""
    try:
        bitmask = ctypes.windll.kernel32.GetLogicalDrives()
    except Exception:
        return []
    drives: List[str] = []
    for i in range(26):
        if bitmask & (1 << i):
            drives.append(f"{chr(65+i)}:\\")
    return drives

def _windows_drive_type(root: str) -> str:
    """Tipos: fixed, removable, remote, cdrom, ramdisk, unknown"""
    DRIVE_TYPES = {0: "unknown", 1: "no_root_dir", 2: "removable", 3: "fixed", 4: "remote", 5: "cdrom", 6: "ramdisk"}
    try:
        t = ctypes.windll.kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))
        return DRIVE_TYPES.get(int(t), "unknown")
    except Exception:
        return "unknown"

# ----------------------------
# Categorias por extensão (simples, rápido)
# ----------------------------
DOC = {
    ".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".csv", ".txt", ".rtf",
    ".md", ".odt", ".ods", ".odp", ".epub", ".mobi", ".json", ".xml", ".yaml", ".yml"
}
CODE = {
    ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".c", ".cpp", ".cs", ".go", ".rs", ".php",
    ".html", ".css", ".scss", ".sql", ".sh", ".bat", ".ps1", ".ini", ".toml", ".cfg", ".env"
}
ARCH = {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".iso"}
MEDIA = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp", ".heic",
    ".mp4", ".mov", ".mkv", ".avi", ".wmv", ".flv", ".mpeg", ".mpg", ".3gp",
    ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"
}

def categorize(ext: str) -> str:
    e = ext.lower()
    if e in DOC:
        return "Documentos"
    if e in CODE:
        return "Código"
    if e in ARCH:
        return "Compactados"
    if e in MEDIA:
        return "Mídia"
    return "Outros"

# ----------------------------
# Temp (opcional) — sem libs externas
# ----------------------------
def read_temp_celsius(temp_cmd: Optional[str] = None) -> Optional[float]:
    """
    Retorna temperatura em °C se possível.
    - temp_cmd: comando personalizado que imprime um número (ex.: 'powershell -NoProfile -Command "..."').
    - fallback: tenta WMI (MSAcpi_ThermalZoneTemperature) via PowerShell.
    Observação: em muitos PCs o WMI não expõe CPU temp; se falhar, retorna None.
    """
    def _try_parse(s: str) -> Optional[float]:
        s = s.strip().replace(",", ".")
        # pega o primeiro número (inteiro/float)
        import re
        m = re.search(r"(-?\d+(?:\.\d+)?)", s)
        if not m:
            return None
        try:
            return float(m.group(1))
        except Exception:
            return None

    if temp_cmd:
        try:
            out = subprocess.check_output(temp_cmd, shell=True, stderr=subprocess.DEVNULL, text=True, timeout=3)
            return _try_parse(out)
        except Exception:
            return None

    # WMI via PowerShell (cai fora se não tiver)
    ps = r'powershell -NoProfile -Command "$t=(Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty CurrentTemperature); if($t){ [math]::Round(($t/10)-273.15,1) }"'
    try:
        out = subprocess.check_output(ps, shell=True, stderr=subprocess.DEVNULL, text=True, timeout=3)
        v = _try_parse(out)
        return v
    except Exception:
        return None

# ----------------------------
# DB
# ----------------------------
MAX_I64 = 9223372036854775807

SCHEMA = r"""
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS runs (
  run_id TEXT PRIMARY KEY,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  roots_json TEXT NOT NULL,
  settings_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS files (
  path TEXT PRIMARY KEY,
  size INTEGER NOT NULL,
  mtime_ns INTEGER NOT NULL,
  ext TEXT NOT NULL,
  category TEXT NOT NULL,
  quicksig TEXT NOT NULL,
  first_seen_run TEXT NOT NULL,
  last_seen_run TEXT NOT NULL,
  status TEXT NOT NULL  -- OK / NEW / MOVED / MISSING / ERR
);

CREATE TABLE IF NOT EXISTS errors (
  run_id TEXT NOT NULL,
  path TEXT NOT NULL,
  err TEXT NOT NULL,
  ts TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_files_quicksig ON files(quicksig);
CREATE INDEX IF NOT EXISTS idx_files_category ON files(category);
CREATE INDEX IF NOT EXISTS idx_files_last_seen ON files(last_seen_run);
"""

def db_connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.executescript(SCHEMA)
    return conn

# ----------------------------
# Scanner
# ----------------------------
def iter_files(root: Path) -> Iterable[Path]:
    # Evita pastas de sistema (ajusta conforme necessário)
    skip_dirs = {"$RECYCLE.BIN", "System Volume Information"}
    for dirpath, dirnames, filenames in os.walk(root, topdown=True):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        for fn in filenames:
            yield Path(dirpath) / fn

def safe_mtime_ns(st) -> int:
    """
    st.st_mtime_ns deveria caber em int64, mas alguns drivers/FS retornam valores esquisitos.
    Aqui blindamos: converte e CLAMPA para 0..MAX_I64.
    """
    try:
        mns = getattr(st, "st_mtime_ns", None)
        if mns is None:
            mns = int(float(st.st_mtime) * 1_000_000_000)
        mns = int(mns)
    except Exception:
        return 0
    if mns < 0:
        return 0
    if mns > MAX_I64:
        # não explode o SQLite
        return MAX_I64
    return mns

def safe_size(st) -> int:
    try:
        sz = int(st.st_size)
    except Exception:
        return 0
    if sz < 0:
        return 0
    if sz > MAX_I64:
        return MAX_I64
    return sz

def quicksig(size: int, mtime_ns: int) -> str:
    return f"{size}:{mtime_ns}"

def upsert_batch(conn: sqlite3.Connection, rows: List[Tuple]) -> None:
    conn.executemany(
        """
        INSERT INTO files(path,size,mtime_ns,ext,category,quicksig,first_seen_run,last_seen_run,status)
        VALUES(?,?,?,?,?,?,?,?,?)
        ON CONFLICT(path) DO UPDATE SET
          size=excluded.size,
          mtime_ns=excluded.mtime_ns,
          ext=excluded.ext,
          category=excluded.category,
          quicksig=excluded.quicksig,
          last_seen_run=excluded.last_seen_run,
          status=excluded.status
        """,
        rows
    )

def count_existing(conn: sqlite3.Connection) -> int:
    try:
        return int(conn.execute("SELECT COUNT(*) FROM files").fetchone()[0])
    except Exception:
        return 0

def maybe_preload_quicksig_map(conn: sqlite3.Connection, mode: str, max_cache: int) -> Optional[Dict[str, str]]:
    """
    MOVED detection:
    - preload: carrega quicksig->path em memória (rápido, usa RAM)
    - query: consulta no SQLite (menos RAM, mais queries)
    - off: não tenta detectar MOVED
    - auto: preload se DB <= max_cache, senão query
    """
    mode = mode.lower()
    if mode == "off":
        return None
    if mode == "auto":
        n = count_existing(conn)
        mode = "preload" if n <= max_cache else "query"

    if mode == "query":
        return {}  # sentinel: dict vazio significa "query mode"
    if mode != "preload":
        return None

    m: Dict[str, str] = {}
    cur = conn.execute("SELECT quicksig, path FROM files WHERE status != 'ERR'")
    for qs, p in cur:
        if qs not in m:
            m[qs] = p
        if len(m) >= max_cache:
            break
    return m

def find_moved_prev_path(conn: sqlite3.Connection, qs: str, qs_map: Optional[Dict[str, str]]) -> Optional[str]:
    if qs_map is None:
        return None
    if qs_map == {}:
        # query mode
        row = conn.execute("SELECT path FROM files WHERE quicksig=? AND status != 'ERR' LIMIT 1", (qs,)).fetchone()
        return row[0] if row else None
    # preload map
    return qs_map.get(qs)

# ----------------------------
# Auto-throttle (não fixo)
# ----------------------------
def auto_sleep_seconds(avg_ms_per_file: float, target_ms: float, max_sleep: float) -> float:
    """
    Se estiver 'lento' (avg > target), dorme um pouco pra aliviar I/O/temperatura.
    Se estiver ok, dorme 0.
    """
    if target_ms <= 0:
        return 0.0
    if avg_ms_per_file <= target_ms:
        return 0.0
    # proporcional suave: quanto pior, mais dorme; limitado por max_sleep
    ratio = min(5.0, avg_ms_per_file / target_ms)
    sleep = min(max_sleep, (ratio - 1.0) * 0.012)  # 0..~0.048 normalmente
    return max(0.0, sleep)

def observe(
    conn: sqlite3.Connection,
    run_id: str,
    roots: List[str],
    limit_files: Optional[int],
    commit_every: int,
    progress_every: int,
    moved_mode: str,
    moved_max_cache: int,
    auto_window: int,
    auto_target_ms: float,
    auto_max_sleep: float,
    temp_warn: float,
    temp_hard: float,
    temp_cmd: Optional[str],
    max_errors: Optional[int],
) -> Dict[str, int]:
    stats = {"OK": 0, "NEW": 0, "MOVED": 0, "UNCHANGED": 0, "ERR": 0}
    processed = 0
    batch: List[Tuple] = []

    qs_map = maybe_preload_quicksig_map(conn, moved_mode, moved_max_cache)

    # janela de auto-throttle
    win_start = time.time()
    win_files = 0
    last_auto_sleep = 0.0

    t0 = time.time()
    for root in roots:
        rootp = Path(root)
        for p in iter_files(rootp):
            if limit_files is not None and processed >= limit_files:
                break
            try:
                st = p.stat()
                size = safe_size(st)
                mns = safe_mtime_ns(st)
                ext = p.suffix.lower()
                cat = categorize(ext)
                qs = quicksig(size, mns)

                prev_path = find_moved_prev_path(conn, qs, qs_map)
                if prev_path and str(p) != prev_path:
                    status = "MOVED"
                    stats["MOVED"] += 1
                else:
                    exists = conn.execute("SELECT 1 FROM files WHERE path=? LIMIT 1", (str(p),)).fetchone()
                    if exists:
                        status = "OK"
                        stats["UNCHANGED"] += 1
                    else:
                        status = "NEW"
                        stats["NEW"] += 1

                batch.append((str(p), size, mns, ext, cat, qs, run_id, run_id, status))
                stats["OK"] += 1
                processed += 1
                win_files += 1

                if processed % progress_every == 0:
                    dt = time.time() - t0
                    print(f"Indexados: {processed:,} arquivos... ({dt:.1f}s)")

                if len(batch) >= commit_every:
                    upsert_batch(conn, batch)
                    conn.commit()
                    batch.clear()

                # auto-throttle: roda por janela de N arquivos (não é fixa; é adaptativa)
                if auto_window > 0 and win_files >= auto_window:
                    elapsed = max(0.0001, time.time() - win_start)
                    avg_ms = (elapsed / win_files) * 1000.0
                    temp = read_temp_celsius(temp_cmd)

                    # regra por temperatura
                    extra = 0.0
                    if temp is not None:
                        if temp >= temp_hard:
                            extra = auto_max_sleep
                        elif temp >= temp_warn:
                            # sobe gradualmente
                            extra = min(auto_max_sleep, (temp - temp_warn) / max(1.0, (temp_hard - temp_warn)) * auto_max_sleep)

                    sleep = max(auto_sleep_seconds(avg_ms, auto_target_ms, auto_max_sleep), extra)

                    # só imprime quando muda (pra não poluir)
                    if abs(sleep - last_auto_sleep) >= 0.005:
                        tmsg = "temp=n/a" if temp is None else f"temp={temp:.1f}C"
                        print(f"[auto-throttle] avg={avg_ms:.2f}ms/arq alvo={auto_target_ms:.2f}ms | {tmsg} -> sleep {sleep:.3f}s")
                        last_auto_sleep = sleep

                    if sleep > 0:
                        time.sleep(sleep)

                    # reseta janela
                    win_start = time.time()
                    win_files = 0

            except Exception as e:
                stats["ERR"] += 1
                processed += 1
                conn.execute(
                    "INSERT INTO errors(run_id,path,err,ts) VALUES(?,?,?,?)",
                    (run_id, str(p), repr(e), _dt.datetime.now().isoformat(timespec="seconds"))
                )
                if max_errors is not None and stats["ERR"] >= max_errors:
                    raise RuntimeError(f"Max errors atingido ({max_errors}). Último erro: {repr(e)}")

        if limit_files is not None and processed >= limit_files:
            break

    if batch:
        upsert_batch(conn, batch)
        conn.commit()

    return stats

def mark_missing(conn: sqlite3.Connection, run_id: str, roots: List[str]) -> int:
    missing = 0
    for r in roots:
        r_norm = str(Path(r)).replace("/", "\\")
        if not r_norm.endswith("\\"):
            r_norm += "\\"
        cur = conn.execute(
            """
            UPDATE files
               SET status='MISSING'
             WHERE last_seen_run != ?
               AND path LIKE ? ESCAPE '\\'
               AND status != 'ERR'
            """,
            (run_id, r_norm.replace("%", "\\%") + "%")
        )
        missing += cur.rowcount if cur.rowcount is not None else 0
    return missing

# ----------------------------
# Relatórios
# ----------------------------
def bytes_human(n: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    x = float(n)
    i = 0
    while x >= 1024 and i < len(units) - 1:
        x /= 1024
        i += 1
    return f"{x:.2f} {units[i]}"

def analyze(conn: sqlite3.Connection, run_id: str, roots: List[str], top_n: int = 12) -> Dict:
    total_files, total_size = conn.execute(
        "SELECT COUNT(*), COALESCE(SUM(size),0) FROM files WHERE last_seen_run=?",
        (run_id,)
    ).fetchone()

    cat_rows = conn.execute(
        """
        SELECT category, COUNT(*), COALESCE(SUM(size),0)
          FROM files
         WHERE last_seen_run=?
         GROUP BY category
         ORDER BY SUM(size) DESC
        """,
        (run_id,)
    ).fetchall()

    ext_rows = conn.execute(
        """
        SELECT ext, COUNT(*), COALESCE(SUM(size),0)
          FROM files
         WHERE last_seen_run=?
         GROUP BY ext
         ORDER BY SUM(size) DESC
         LIMIT ?
        """,
        (run_id, top_n)
    ).fetchall()

    # Pastas mais pesadas: estimativa pelos top 5000 arquivos
    top_files = conn.execute(
        "SELECT path, size FROM files WHERE last_seen_run=? ORDER BY size DESC LIMIT 5000",
        (run_id,)
    ).fetchall()

    buckets: Dict[str, int] = {}
    roots_norm = []
    for r in roots:
        rn = str(Path(r)).replace("/", "\\")
        if not rn.endswith("\\"):
            rn += "\\"
        roots_norm.append(rn)

    for path, sz in top_files:
        p = path.replace("/", "\\")
        root_hit = None
        for rn in roots_norm:
            if p.lower().startswith(rn.lower()):
                root_hit = rn
                break
        if root_hit:
            rest = p[len(root_hit):]
            first = rest.split("\\", 1)[0] if rest else ""
            key = f"{root_hit}{first}" if first else root_hit
        else:
            key = p[:3] if len(p) >= 3 and p[1:3] == ":\\" else ""
        buckets[key] = buckets.get(key, 0) + int(sz)

    top_folders = sorted(buckets.items(), key=lambda x: x[1], reverse=True)[:top_n]

    return {
        "run_id": run_id,
        "roots": roots,
        "total_files": int(total_files),
        "total_size_bytes": int(total_size),
        "categories": [{"name": c, "files": int(n), "bytes": int(b)} for (c, n, b) in cat_rows],
        "top_extensions": [{"ext": e or "(sem)", "files": int(n), "bytes": int(b)} for (e, n, b) in ext_rows],
        "top_folders_by_size_from_top5000": [{"folder": f, "bytes": int(b)} for (f, b) in top_folders],
    }

def write_reports(out_dir: Path, summary: Dict) -> Tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    jpath = out_dir / "resumo.json"
    hpath = out_dir / "relatorio_mapa_do_caos.html"
    jpath.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    cats = "\n".join(
        f"<tr><td>{c['name']}</td><td>{c['files']:,}</td><td>{bytes_human(c['bytes'])}</td></tr>"
        for c in summary["categories"]
    )
    exts = "\n".join(
        f"<tr><td>{e['ext']}</td><td>{e['files']:,}</td><td>{bytes_human(e['bytes'])}</td></tr>"
        for e in summary["top_extensions"]
    )
    tops = "\n".join(
        f"<tr><td>{t['folder']}</td><td>{bytes_human(t['bytes'])}</td></tr>"
        for t in summary["top_folders_by_size_from_top5000"]
    )

    html = f"""<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8"/>
<title>NeverLost — Mapa do Caos Digital</title>
<style>
body{{font-family:Segoe UI,Arial,sans-serif;margin:24px;}}
h1{{margin:0 0 8px 0;}}
small{{color:#666;}}
table{{border-collapse:collapse;width:100%;margin:12px 0;}}
th,td{{border:1px solid #ddd;padding:8px;text-align:left;}}
th{{background:#f6f6f6;}}
.kpi{{display:flex;gap:16px;flex-wrap:wrap;margin:14px 0;}}
.card{{border:1px solid #ddd;border-radius:10px;padding:12px 14px;min-width:180px;}}
.note{{margin-top:8px;color:#444;}}
</style>
</head>
<body>
<h1>Mapa do Caos Digital</h1>
<small>Gerado localmente • Nenhum arquivo foi modificado • run={summary['run_id']}</small>

<div class="kpi">
  <div class="card"><b>Total de arquivos</b><br>{summary['total_files']:,}</div>
  <div class="card"><b>Tamanho total</b><br>{bytes_human(summary['total_size_bytes'])}</div>
  <div class="card"><b>Roots</b><br>{"<br>".join(summary["roots"])}</div>
</div>

<p class="note">Dica: rode novamente mais tarde. O NeverLost é incremental — ele só atualiza o que mudou.</p>

<h2>Distribuição por categoria</h2>
<table>
<tr><th>Categoria</th><th>Arquivos</th><th>Tamanho</th></tr>
{cats}
</table>

<h2>Top extensões</h2>
<table>
<tr><th>Extensão</th><th>Arquivos</th><th>Tamanho</th></tr>
{exts}
</table>

<h2>Pastas mais pesadas (estimativa por top 5000 arquivos)</h2>
<table>
<tr><th>Pasta</th><th>Tamanho</th></tr>
{tops}
</table>

</body>
</html>
"""
    hpath.write_text(html, encoding="utf-8")
    return jpath, hpath

# ----------------------------
# Main
# ----------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description="NeverLost — Mapa do Caos Digital (offline/read-only)")
    ap.add_argument("--out", default="neverlost_output", help="Pasta de saída (relatórios + db)")
    ap.add_argument("--db", default=None, help="Caminho do DB SQLite (default: <out>/neverlost.db)")
    ap.add_argument("--roots", nargs="*", default=None,
                    help="Roots a observar (ex: C:\\ D:\\ K:\\ R:\\). Se vazio, autodetecta (fixos).")
    ap.add_argument("--include-removable", action="store_true", help="Inclui pendrives/removíveis no autodetect")
    ap.add_argument("--limit-files", type=int, default=None, help="Limite de arquivos (teste). Default: sem limite")

    ap.add_argument("--commit-every", type=int, default=2000, help="Batch commit (default 2000)")
    ap.add_argument("--progress-every", type=int, default=10000, help="Print a cada N arquivos (default 10000)")

    # MOVED detection
    ap.add_argument("--moved-mode", default="auto", choices=["auto", "preload", "query", "off"],
                    help="Como detectar MOVED (auto|preload|query|off).")
    ap.add_argument("--moved-max-cache", type=int, default=500000,
                    help="Limite de quicksigs em memória no preload (default 500k).")

    # Auto throttle
    ap.add_argument("--auto-window", type=int, default=30000,
                    help="Janela (em arquivos) para auto-throttle. 0 desliga. Default 30000.")
    ap.add_argument("--auto-target-ms", type=float, default=2.0,
                    help="Alvo de ms/arquivo (quanto menor, mais agressivo). Default 2.0.")
    ap.add_argument("--auto-max-sleep", type=float, default=0.12,
                    help="Sleep máximo aplicado pelo auto-throttle. Default 0.12s.")

    ap.add_argument("--temp-warn", type=float, default=72.0, help="Temperatura (°C) pra começar a aliviar. Default 72.")
    ap.add_argument("--temp-hard", type=float, default=82.0, help="Temperatura (°C) pra aliviar forte. Default 82.")
    ap.add_argument("--temp-cmd", default=None,
                    help="Comando que imprime temperatura em °C (se quiser customizar).")

    ap.add_argument("--max-errors", type=int, default=0,
                    help="Se >0, para quando atingir N erros (debug). 0 = ilimitado.")

    args = ap.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = Path(args.db) if args.db else (out_dir / "neverlost.db")

    # Roots
    if args.roots and len(args.roots) > 0:
        roots = [r if r.endswith("\\") else (r + "\\") for r in args.roots]
    else:
        roots = []
        for d in _windows_logical_drives():
            t = _windows_drive_type(d)
            if t == "fixed" or (args.include_removable and t == "removable"):
                roots.append(d)

    roots = [r for r in roots if Path(r).exists()]
    if not roots:
        print("Nenhum root válido encontrado. Use --roots C:\\ D:\\ K:\\ R:\\ (etc).")
        sys.exit(2)

    run_id = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")

    settings = {
        "commit_every": args.commit_every,
        "progress_every": args.progress_every,
        "moved_mode": args.moved_mode,
        "moved_max_cache": args.moved_max_cache,
        "auto_window": args.auto_window,
        "auto_target_ms": args.auto_target_ms,
        "auto_max_sleep": args.auto_max_sleep,
        "temp_warn": args.temp_warn,
        "temp_hard": args.temp_hard,
        "temp_cmd": bool(args.temp_cmd),
    }

    conn = db_connect(db_path)
    conn.execute(
        "INSERT OR REPLACE INTO runs(run_id, started_at, roots_json, settings_json) VALUES(?,?,?,?)",
        (run_id,
         _dt.datetime.now().isoformat(timespec="seconds"),
         json.dumps(roots, ensure_ascii=False),
         json.dumps(settings, ensure_ascii=False))
    )
    conn.commit()

    print(f"[{_dt.datetime.now().isoformat(timespec='seconds')}] OBSERVAR iniciado | run={run_id}")
    print(f"[{_dt.datetime.now().isoformat(timespec='seconds')}] Roots: {roots}")
    if args.auto_window > 0:
        print(f"[auto-throttle] window={args.auto_window:,} alvo={args.auto_target_ms}ms/arq | temp_warn={args.temp_warn}C temp_hard={args.temp_hard}C")

    t0 = time.time()
    stats = observe(
        conn=conn,
        run_id=run_id,
        roots=roots,
        limit_files=args.limit_files,
        commit_every=args.commit_every,
        progress_every=args.progress_every,
        moved_mode=args.moved_mode,
        moved_max_cache=args.moved_max_cache,
        auto_window=args.auto_window,
        auto_target_ms=args.auto_target_ms,
        auto_max_sleep=args.auto_max_sleep,
        temp_warn=args.temp_warn,
        temp_hard=args.temp_hard,
        temp_cmd=args.temp_cmd,
        max_errors=(args.max_errors if args.max_errors > 0 else None),
    )

    print("🔎 Marcando MISSING (itens sumidos)...")
    missing = mark_missing(conn, run_id, roots)
    conn.commit()

    conn.execute(
        "UPDATE runs SET finished_at=? WHERE run_id=?",
        (_dt.datetime.now().isoformat(timespec="seconds"), run_id)
    )
    conn.commit()

    summary = analyze(conn, run_id, roots, top_n=12)
    summary["stats"] = stats
    summary["missing_marked"] = int(missing)
    summary["elapsed_seconds"] = round(time.time() - t0, 2)

    jpath, hpath = write_reports(out_dir, summary)

    print(f"✅ Indexação concluída: {summary['total_files']:,} arquivos em {summary['elapsed_seconds']}s")
    print("Gerado:")
    print(f"- {jpath}")
    print(f"- {hpath}")

    conn.close()

if __name__ == "__main__":
    main()
