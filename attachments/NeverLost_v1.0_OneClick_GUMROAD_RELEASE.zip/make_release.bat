@echo off
setlocal ENABLEDELAYEDEXPANSION

REM ==========================================================
REM NeverLost v1.0 — Criar ZIP FINAL para Gumroad
REM 1) build_windows.bat (gera dist\NeverLost.exe)
REM 2) este script monta Release\NeverLost_v1.0_OneClick\
REM 3) cria NeverLost_v1.0_OneClick.zip via PowerShell
REM ==========================================================

set RELEASE_DIR=Release\NeverLost_v1.0_OneClick

if not exist dist\NeverLost.exe (
  echo ERRO: dist\NeverLost.exe nao encontrado.
  echo Rode primeiro: build_windows.bat
  pause
  exit /b 1
)

echo [NeverLost] Montando pasta de release...
if exist Release rmdir /s /q Release
mkdir "%RELEASE_DIR%"

copy /y "dist\NeverLost.exe" "%RELEASE_DIR%\" >nul
copy /y "START_HERE.txt" "%RELEASE_DIR%\" >nul
copy /y "README.md" "%RELEASE_DIR%\" >nul
copy /y "LICENSE.txt" "%RELEASE_DIR%\" >nul
copy /y "GUMROAD_COPY.txt" "%RELEASE_DIR%\" >nul

echo [NeverLost] Criando ZIP...
powershell -NoLogo -NoProfile -Command ^
  "Compress-Archive -Path '%RELEASE_DIR%\*' -DestinationPath 'NeverLost_v1.0_OneClick.zip' -Force"

echo.
echo OK! Arquivo gerado: NeverLost_v1.0_OneClick.zip
echo Esse e o ZIP que voce sobe no Gumroad.
echo.
pause
