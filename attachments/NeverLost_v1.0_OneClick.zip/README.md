# NeverLost v1.0 — Mapa do Caos Digital (One‑Click • Offline)

**Scanner Forense de Soberania Digital Pessoal.**  
**100% offline • somente leitura (read‑only) • não move / não apaga nada**  
Gera **relatório HTML** + **banco incremental (SQLite)** para você enxergar *onde está o peso* e *onde mora a bagunça*.

> **Slogan:** Sua bagunça nunca mais perdida.  
> **Tagline (EN):** Personal Digital Forensics for Normal People.

---

## O que isso resolve (em 10 segundos)

Você abre o NeverLost, escolhe onde salvar o relatório, clica **Iniciar** e recebe um **Mapa do Caos**:
- Quais categorias estão comendo seu disco (Mídia, Documentos, Compactados…)
- Quais extensões são os “vilões” (.img, .zip, .mp4…)
- Onde estão as pastas mais pesadas
- Duplicatas **candidatas** (nome + tamanho), sem destruir nada

---

## Começo rápido (pessoas normais)

1) **Extraia** o ZIP (botão direito → “Extrair tudo…”)  
2) Abra:
- **Preferido:** `NeverLost.exe` *(quando a versão com EXE estiver presente)*  
- **Alternativa:** `NeverLost_UI.py` *(requer Python instalado)*
3) Clique **Escolher…** e selecione uma pasta de saída (ex.: `D:\NeverLost_Output`)  
4) Deixe marcado **Iniciar análise em TODOS os discos automaticamente**  
5) Clique **Iniciar análise**  
6) Quando terminar, clique **Abrir pasta de saída** e abra `relatorio_mapa_do_caos.html`

**Pronto.** Você vai ver cards com total de arquivos, tamanho e os discos analisados.

---

## Discos / Roots: “ele olha tudo sozinho?”

**Sim, por padrão.**  
- Se você marcar **“Iniciar análise em TODOS os discos automaticamente”**, o NeverLost detecta os discos do PC e varre todos os **discos fixos** (SSD/HD).  
- Se marcar **“Incluir pendrives / removíveis”**, ele também inclui unidades removíveis (pendrive/HD externo), quando conectadas.

**Modo manual (avançado):**  
Desmarque “Todos os discos” e marque só os discos que você quer (checkboxes).

> Motivo: gente compra praticidade — então a opção padrão é “um clique e vai”.

---

## Desempenho e segurança (auto‑throttle)

O NeverLost pode desacelerar automaticamente para não fritar seu PC.
- **Janela:** quantos arquivos ele mede antes de ajustar
- **Alvo (ms/arq):** velocidade alvo (ex.: 2.0)
- **Sleep máx:** pausa máxima quando precisar
- **Temp aviso/hard:** limites de temperatura para agir mais agressivo

Se você mora num forno (sem ar condicionado 😅), isso aqui é seu seguro de vida.

---

## Saídas geradas

Na pasta de saída, você vai encontrar:
- `relatorio_mapa_do_caos.html` (o mapa visual)
- `resumo.json` (dados do relatório)
- `neverlost.db` / `eddy_observer.db` (SQLite incremental — “memória” do scan)

---

## Requisitos

### Para usar com EXE (recomendado)
- Windows 10/11

### Para usar com Python (alternativa)
- Python 3.10+ instalado
- Executar: `py NeverLost_UI.py`

---

## Solução de problemas (rápido)

- **“Não abre / Windows bloqueou”** → clique com botão direito → Propriedades → “Desbloquear” (se existir)  
- **Escolhi uma pasta e não gerou nada** → escolha uma pasta onde você tenha permissão (ex.: dentro do seu usuário)  
- **Muito lento** → diminua o “Alvo (ms/arq)” ou aumente “Janela”; deixe auto‑throttle fazer o trabalho  
- **Drive removível não aparece** → clique **Recarregar discos** com o pendrive/HD externo conectado

---

## Prova real (dados do meu caos)

Um run real mapeou **1,063,643 arquivos** e **~1.65 TB** (offline), em discos: C:\, D:\, K:\, R:\.

---

## Licença

MIT (veja `LICENSE.txt`).

