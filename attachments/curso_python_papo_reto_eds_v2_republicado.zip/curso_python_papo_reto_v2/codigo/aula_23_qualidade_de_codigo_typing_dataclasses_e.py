"""Aula 23 — Qualidade de código: typing, dataclasses e padrões de projeto simples

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 23: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
