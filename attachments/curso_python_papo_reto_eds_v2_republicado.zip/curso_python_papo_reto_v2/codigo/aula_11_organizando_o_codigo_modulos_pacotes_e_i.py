"""Aula 11 — Organizando o código: módulos, pacotes e import do jeito certo

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 11: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
