"""Aula 13 — Arquivos: pathlib, CSV e JSON"""

from pathlib import Path
import json
import csv

def main():
    pasta = Path("dados")
    pasta.mkdir(exist_ok=True)

    # JSON
    dados = {"nome": "Julia", "stack": ["js", "python"], "backend": True}
    (pasta/"perfil.json").write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")

    # CSV
    linhas = [
        {"produto": "café", "preco": 12.5},
        {"produto": "leite", "preco": 6.0},
    ]
    with (pasta/"compras.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["produto", "preco"])
        writer.writeheader()
        writer.writerows(linhas)

    print("Arquivos criados em:", pasta.resolve())

if __name__ == "__main__":
    main()
