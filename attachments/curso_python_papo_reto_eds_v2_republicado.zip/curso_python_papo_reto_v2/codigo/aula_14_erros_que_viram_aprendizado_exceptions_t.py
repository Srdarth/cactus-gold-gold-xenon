"""Aula 14 — Exceptions"""

def divide(a: float, b: float) -> float:
    if b == 0:
        raise ZeroDivisionError("b não pode ser zero")
    return a / b

def main():
    try:
        a = float(input("a: "))
        b = float(input("b: "))
        print("a/b =", divide(a, b))
    except ValueError:
        print("Digite números válidos.")
    except ZeroDivisionError as e:
        print("Erro:", e)

if __name__ == "__main__":
    main()
