"""Aula 01 — Como o Python funciona (interprete, script, REPL)

Rode:
    python codigo/aula_01_interprete.py
"""

def mostra_namespace():
    # Em Python, nomes apontam para objetos.
    nome = "Julia"
    idade = 22
    print("nome ->", nome)
    print("idade ->", idade)

def main():
    print("Olá! Isso é um arquivo .py executado pelo interpretador.")
    mostra_namespace()

if __name__ == "__main__":
    main()
