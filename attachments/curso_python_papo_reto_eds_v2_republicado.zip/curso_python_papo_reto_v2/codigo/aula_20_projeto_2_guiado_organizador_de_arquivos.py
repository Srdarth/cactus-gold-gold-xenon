"""Aula 20 — Projeto 2 guiado: Organizador de arquivos + relatório em CSV/JSON

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 20: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
