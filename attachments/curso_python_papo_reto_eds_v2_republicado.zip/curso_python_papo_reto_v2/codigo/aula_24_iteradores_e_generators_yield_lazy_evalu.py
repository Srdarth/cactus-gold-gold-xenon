"""Aula 24 — Iteradores e generators: yield, lazy evaluation e memória

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 24: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
