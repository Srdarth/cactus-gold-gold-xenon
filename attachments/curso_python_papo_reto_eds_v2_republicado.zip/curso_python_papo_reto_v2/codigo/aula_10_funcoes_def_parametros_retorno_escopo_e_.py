"""Aula 10 — Funções + mini-projeto 1 (calculadora)"""

def soma(a: float, b: float) -> float:
    return a + b

def sub(a: float, b: float) -> float:
    return a - b

def main():
    print("Calculadora (soma/sub)")
    op = input("Operação (+ ou -): ").strip()
    a = float(input("a: ").replace(",", "."))
    b = float(input("b: ").replace(",", "."))

    if op == "+":
        r = soma(a, b)
    elif op == "-":
        r = sub(a, b)
    else:
        print("Operação inválida.")
        return

    print("Resultado:", r)

if __name__ == "__main__":
    main()
