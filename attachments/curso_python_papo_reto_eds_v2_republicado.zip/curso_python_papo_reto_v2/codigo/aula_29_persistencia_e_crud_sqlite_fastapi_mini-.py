"""Aula 29 — CRUD com SQLite + FastAPI (mini API completa)

Instale:
    pip install fastapi uvicorn

Rode:
    uvicorn codigo.aula_29_crud_fastapi:app --reload
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import sqlite3
from pathlib import Path

app = FastAPI(title="Mini CRUD - EDS")

DB_PATH = Path("dados") / "crud.db"
DB_PATH.parent.mkdir(exist_ok=True)

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS clientes(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT
            )
        """)
init_db()

class ClienteIn(BaseModel):
    nome: str
    email: str | None = None

@app.post("/clientes")
def criar(cliente: ClienteIn):
    with sqlite3.connect(DB_PATH) as con:
        cur = con.execute("INSERT INTO clientes(nome,email) VALUES(?,?)", (cliente.nome, cliente.email))
        con.commit()
        return {"id": cur.lastrowid, **cliente.model_dump()}

@app.get("/clientes")
def listar():
    with sqlite3.connect(DB_PATH) as con:
        rows = con.execute("SELECT id,nome,email FROM clientes ORDER BY id DESC").fetchall()
    return [{"id": r[0], "nome": r[1], "email": r[2]} for r in rows]

@app.get("/clientes/{cliente_id}")
def obter(cliente_id: int):
    with sqlite3.connect(DB_PATH) as con:
        row = con.execute("SELECT id,nome,email FROM clientes WHERE id=?", (cliente_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Cliente não encontrado")
    return {"id": row[0], "nome": row[1], "email": row[2]}
