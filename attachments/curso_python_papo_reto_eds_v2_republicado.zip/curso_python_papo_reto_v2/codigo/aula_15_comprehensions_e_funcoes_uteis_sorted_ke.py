"""Aula 15 — Comprehensions e funções úteis: sorted(), key=, any/all, zip

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 15: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
