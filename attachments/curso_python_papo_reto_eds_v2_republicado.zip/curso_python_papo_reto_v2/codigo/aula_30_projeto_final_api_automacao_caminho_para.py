"""Aula 30 — Projeto Final: API + automação (caminho para você evoluir sozinho)

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 30: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
