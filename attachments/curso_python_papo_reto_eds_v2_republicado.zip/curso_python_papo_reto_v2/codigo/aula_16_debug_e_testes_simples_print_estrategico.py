"""Aula 16 — Debug e testes simples: print estratégico, assert, logging e REPL

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 16: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
