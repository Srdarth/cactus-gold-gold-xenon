"""Aula 25 — Decorators e context managers: “envolver” funções e usar with

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 25: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
