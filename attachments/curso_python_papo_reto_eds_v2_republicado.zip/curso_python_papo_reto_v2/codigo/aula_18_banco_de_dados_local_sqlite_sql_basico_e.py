"""Aula 18 — SQLite (sqlite3)"""

import sqlite3
from pathlib import Path

DB_PATH = Path("dados") / "app.db"

def main():
    DB_PATH.parent.mkdir(exist_ok=True)

    with sqlite3.connect(DB_PATH) as con:
        cur = con.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS clientes(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT UNIQUE
            )
        """)
        cur.execute("INSERT OR IGNORE INTO clientes(nome, email) VALUES(?,?)", ("Julia", "julia@email.com"))
        con.commit()

        cur.execute("SELECT id, nome, email FROM clientes")
        for row in cur.fetchall():
            print(row)

    print("DB em:", DB_PATH.resolve())

if __name__ == "__main__":
    main()
