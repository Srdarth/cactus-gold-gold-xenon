"""Aula 28 — JS consumindo API (arquivo de referência)

Este arquivo é só um lembrete. O exemplo JS está em:
    projetos/projeto_final/frontend_exemplo.html
"""

def main():
    print("Veja o HTML do projeto final para o fetch() consumindo a API.")

if __name__ == "__main__":
    main()
