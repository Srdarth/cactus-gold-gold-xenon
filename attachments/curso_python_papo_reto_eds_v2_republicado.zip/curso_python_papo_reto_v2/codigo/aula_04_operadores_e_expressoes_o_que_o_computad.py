"""Aula 04 — Operadores e expressões: o que o computador realmente calcula

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 04: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
