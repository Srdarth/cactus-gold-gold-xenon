"""Aula 21 — POO: classes e objetos"""

class Conta:
    def __init__(self, titular: str, saldo: float = 0.0):
        self.titular = titular
        self.saldo = saldo

    def depositar(self, valor: float) -> None:
        if valor <= 0:
            raise ValueError("valor deve ser positivo")
        self.saldo += valor

    def sacar(self, valor: float) -> None:
        if valor <= 0:
            raise ValueError("valor deve ser positivo")
        if valor > self.saldo:
            raise ValueError("saldo insuficiente")
        self.saldo -= valor

def main():
    c = Conta("Edson", 50)
    c.depositar(30)
    c.sacar(10)
    print(c.titular, c.saldo)

if __name__ == "__main__":
    main()
