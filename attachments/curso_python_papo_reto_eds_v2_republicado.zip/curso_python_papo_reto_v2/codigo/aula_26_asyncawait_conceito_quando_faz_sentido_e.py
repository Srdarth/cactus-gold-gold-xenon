"""Aula 26 — Async/await (conceito): quando faz sentido e quando não faz

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 26: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
