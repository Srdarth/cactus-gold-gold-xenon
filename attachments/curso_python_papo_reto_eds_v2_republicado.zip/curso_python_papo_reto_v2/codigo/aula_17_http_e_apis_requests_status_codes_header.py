"""Aula 17 — HTTP e APIs com requests

Instale:
    pip install requests
"""

import requests

def main():
    url = "https://httpbin.org/get"
    r = requests.get(url, timeout=10)

    print("status:", r.status_code)
    data = r.json()
    print("origem:", data.get("origin"))
    print("headers recebidos:", list(data.get("headers", {}).keys())[:5], "...")

if __name__ == "__main__":
    main()
