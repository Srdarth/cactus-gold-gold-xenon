"""Aula 22 — POO no mundo real: composição, herança e dunder methods

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 22: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
