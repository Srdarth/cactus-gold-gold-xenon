"""Aula 19 — Arquitetura do Papo Reto: separar camadas (I/O, regra, dados)

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 19: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
