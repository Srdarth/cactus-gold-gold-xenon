"""Aula 05 — Strings na vida real"""

def limpa_cpf(cpf: str) -> str:
    return "".join(ch for ch in cpf if ch.isdigit())

def main():
    raw = input("Digite um CPF (com pontos e traço): ")
    cpf = limpa_cpf(raw)

    if len(cpf) != 11:
        print("CPF deve ter 11 dígitos.")
        return

    # f-string
    print(f"CPF limpo: {cpf}")
    # slicing
    print("Primeiros 3:", cpf[:3])
    print("Últimos 2:", cpf[-2:])

if __name__ == "__main__":
    main()
