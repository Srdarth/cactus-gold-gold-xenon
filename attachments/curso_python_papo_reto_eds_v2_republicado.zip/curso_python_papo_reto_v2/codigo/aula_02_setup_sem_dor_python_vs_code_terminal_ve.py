"""Aula 02 — Setup: terminal + venv (conceito) + pip (conceito)

Observação: este arquivo não cria venv sozinho.
Ele só explica o que você deve rodar no terminal.

Terminal (Windows PowerShell):
    py -m venv .venv
    .\.venv\Scripts\Activate.ps1
    python -m pip install --upgrade pip

Terminal (Linux/Mac):
    python3 -m venv .venv
    source .venv/bin/activate
    python -m pip install --upgrade pip
"""

def main():
    print("Veja os comandos no topo do arquivo e rode no seu terminal.")
    print("Dica: crie um projeto por pasta e use .venv em cada um.")

if __name__ == "__main__":
    main()
