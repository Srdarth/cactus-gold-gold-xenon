"""Aula 07 — Dicionários e sets"""

def main():
    pessoa = {"nome": "Edson", "cidade": "Rio", "idade": 33}
    print(pessoa["nome"])
    pessoa["idade"] += 1

    # set remove repetidos
    tags = {"python", "backend", "python", "api"}
    print("tags:", tags)

    # dica: get evita KeyError
    print("apelido:", pessoa.get("apelido", "(não informado)"))

if __name__ == "__main__":
    main()
