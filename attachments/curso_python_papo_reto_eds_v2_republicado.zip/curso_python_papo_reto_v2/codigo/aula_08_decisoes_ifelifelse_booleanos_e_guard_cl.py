"""Aula 08 — Decisões: if/elif/else, booleanos e “guard clauses”

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 08: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
