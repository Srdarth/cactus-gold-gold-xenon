"""Aula 03 — Variáveis, tipos e I/O

Exemplos:
- print() para saída
- input() para entrada (sempre string)
- conversão com int/float/str
"""

def main():
    nome = input("Qual seu nome? ")
    idade_txt = input("Qual sua idade? ")

    # input() sempre devolve str:
    print(type(nome), type(idade_txt))

    try:
        idade = int(idade_txt)
    except ValueError:
        print("Idade inválida. Digite só números.")
        return

    print(f"Olá, {nome}! Em 1 ano você terá {idade + 1}.")

if __name__ == "__main__":
    main()
