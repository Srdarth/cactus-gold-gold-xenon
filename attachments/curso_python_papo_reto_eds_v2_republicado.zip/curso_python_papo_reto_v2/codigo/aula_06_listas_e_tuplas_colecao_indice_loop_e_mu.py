"""Aula 06 — Listas e tuplas"""

def main():
    compras = ["arroz", "feijão", "café"]
    compras.append("leite")
    print("Lista:", compras)

    # tupla: imutável (boa para 'constantes' pequenas)
    meses = ("jan", "fev", "mar")
    print("Tupla:", meses)

    # loop
    for i, item in enumerate(compras, start=1):
        print(i, "-", item)

if __name__ == "__main__":
    main()
