"""Aula 12 — pip e ambientes: requirements.txt, venv e dependências sem bagunça

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 12: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
