"""Aula 09 — Repetição: for/while, range(), enumerate() e padrões

Este arquivo traz exemplos simples. Leia a aula em `aulas/`.
"""

def main():
    print("Aula 09: veja o material em Markdown na pasta aulas/.")

if __name__ == "__main__":
    main()
