"""Aula 27 — FastAPI (backend mínimo)

Instale:
    pip install fastapi uvicorn

Rode:
    uvicorn codigo.aula_27_fastapi:app --reload

Abra:
    http://127.0.0.1:8000/docs
"""

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="EDS API - Papo Reto")

class ClienteIn(BaseModel):
    nome: str
    email: str | None = None

@app.get("/")
def health():
    return {"ok": True, "msg": "API no ar"}

@app.post("/clientes")
def criar_cliente(cliente: ClienteIn):
    # aqui você salvaria em banco
    return {"criado": True, "cliente": cliente.model_dump()}
