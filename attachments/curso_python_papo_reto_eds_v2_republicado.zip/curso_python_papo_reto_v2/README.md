# Curso Python Papo Reto — do Zero ao Backend (EDS | Exclusivity ESL)

**Versão:** v2.0 (gerado em 2026-01-28)  
**Autor/Marca:** Eddy Digital Solutions (EDS) | Exclusivity ESL  
**Assinatura padrão:** Creation by Digital Specialist Edson Souza Leite, a work of Eddy Digital Solutions, Exclusivity ESL

## Para quem é este curso
Para quem **quer fazer** e às vezes sente que “faz, mas não entende o que está conectando”.  
A ideia aqui é explicar **o porquê**, **o como**, e **o que acontece por trás dos panos**, sem enrolação.

> Se você é como a Júlia (curte JavaScript e backend, mas não pegou ainda “como Python conecta as coisas”), este curso é pra você.

## Como usar esta pasta
- `00_GUIA_DO_CURSO.pdf` → visão geral, trilha e como estudar
- `01_APOSTILA_COMPLETA.pdf` → apostila única (tudo em um lugar)
- `aulas/` → aulas em Markdown (leitura no celular/PC)
- `codigo/` → exemplos prontos para rodar
- `exercicios/` → lista de exercícios
- `solucoes/` → soluções comentadas
- `projetos/` → projetos guiados (passo a passo)
- `checklists/` → checklists de revisão e “erros comuns”

## Requisitos
- Um PC simples (Windows/Linux/Mac)  
- Python 3.11+ recomendado  
- VS Code recomendado (mas pode usar qualquer editor)  

## Regra de ouro (Papo Reto)
1. Rode o código.
2. Quebre o código (de propósito).
3. Conserte e explique com suas palavras.

Boa jornada. 🚀
