# NeverLost v1.0 — Observer Edition (One-Click)
**Scanner Forense de Soberania Digital Pessoal**  
**Personal Digital Mapping Forensic Scanner (Offline)**

**NeverLost** mapeia o “caos digital” do seu PC **sem enviar nada pra nuvem** e **sem modificar arquivos**.  
Ele gera:
- **relatório HTML** (visual, fácil de entender)
- **banco incremental (SQLite)** (para você não reindexar tudo do zero toda vez)

> **Modo Observer (somente leitura):** não move / não apaga / não renomeia nada.

---

## Começo rápido (1 minuto)
1. Abra `NeverLost_Observer.exe`
2. Escolha a **pasta de saída** (onde vão ficar o relatório + DB)
3. Use um dos modos:
   - **Modo simples (recomendado):** marque **“Iniciar análise em TODOS os discos automaticamente”**
   - **Modo seletivo:** desmarque “todos” e marque só os discos que quiser
4. (Opcional) marque **“Incluir pendrives / removíveis”**
5. Clique em **Iniciar análise**
6. Ao finalizar, abra o arquivo **`relatorio_mapa_do_caos.html`** na pasta de saída

---

## O que você recebe
- `NeverLost_Observer.exe` (One-Click)
- `START_HERE.txt` (passo a passo ultra simples)
- `README.md` (este manual)
- `LICENSE.txt`
- Pasta `EXEMPLOS/` (relatórios reais de testes diferentes)
- Pasta `SCREENSHOTS/` (prints para referência)

---

## Por que existem “vários relatórios” nos exemplos?
Porque cada execução (“run”) pode ser diferente:
- você selecionou discos diferentes (ex.: só C: e D:, ou C/D/K/R, etc.)
- o computador tinha mais/menos arquivos no momento
- o relatório pode ter arredondamentos (1.50 TB vs 1.53 TB)

**Isso não é erro — são testes e cenários diferentes.**

---

## Privacidade e segurança
- 100% offline.
- O app só **lê** metadados (caminho, tamanho, extensão, datas) para gerar o mapa.
- Não faz upload de nada.
- Não altera seus arquivos.

---

## Requisitos
- Windows 10/11
- Espaço livre na pasta de saída para o DB + relatórios
- Permissão de leitura nos discos escolhidos

---

## Problemas comuns (rápido)
**“Windows protegeu seu PC”**  
Clique em “Mais informações” → “Executar assim mesmo”.

**Antivírus acusou o EXE**  
PyInstaller costuma gerar falsos positivos. O comportamento do NeverLost é simples: offline e read-only.

**Pendrive não apareceu**  
Clique em “Recarregar discos” e/ou marque “Incluir pendrives / removíveis”.

**Demorou muito**  
Normal no primeiro scan (principalmente HDs grandes e cheios). Depois fica mais rápido (incremental).

---

## Roadmap (versão Pro — depois)
- Detecção de duplicatas por hash (mais preciso)
- Relatórios por pasta/projeto
- Exportações (CSV/JSON avançado)
- Sugestões de organização (sem mexer nos arquivos, só recomendações)

---

## Contato / suporte
- X/Twitter: **@3ddY99**
